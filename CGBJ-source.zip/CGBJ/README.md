<!-- Modified for the CGBJ fork on 2026-11-25: project branding and/or documentation. Original XCL and third-party notices remain applicable. -->
# CGBJ – Xbox Series X|S → Windows compatibility layer

**CGBJ is a GPL-2.0-only fork of [XCL](https://github.com/ivall/xcl).** It is an independent compatibility-layer project, not an official product of any game publisher or platform holder. Upstream contributors retain their rights; no ownership of third-party code is claimed. See [FORK_NOTES.md](FORK_NOTES.md) and [THIRD_PARTY.md](THIRD_PARTY.md).

The compatibility claims, game table, historical measurements and examples below are inherited upstream documentation, not independently verified CGBJ results. The modified CGBJ source has not yet been validated on Windows in this packaging environment.

[![Discord](https://img.shields.io/badge/Upstream%20Discord-join%20the%20server-5865F2?logo=discord&logoColor=white)](https://discord.gg/xcl)
**Upstream XCL Discord: <https://discord.gg/xcl>**

CGBJ runs Xbox Series X|S (GDK) game files on a Windows PC **without CPU emulation**: the game's
x64 code runs natively and CGBJ stands in for the console libraries the PC does not have
(`kernelx.dll`, XGameRuntime, `d3d12_xs.dll`, …) – in the spirit of Wine/Proton. The console's
GPU code (RDNA2 machine code) is recompiled into PC shaders (HLSL → DXIL).

**Project state:** retail games run – Minecraft Preview and Unicorn Overlord are fully
playable, Fortnite and XDefiant work as far as each game goes without its online services;
see [Games](#games). The foundation is tested against real data from retail games
(shader packs, texture archives, movies and the console DLLs they ship). Details, measurements and
next steps:
[`HANDOFF.md`](HANDOFF.md); design: [`docs/specs/2026-11-20-cgbj-design.md`](docs/specs/2026-11-20-cgbj-design.md).

## Games

| Game | Package (version) | State | What works | Limits |
|---|---|---|---|---|
| **Minecraft Preview** | `Microsoft.MinecraftBeta` 1.18.3064.0 | ✅ | fully playable | – |
| **Unicorn Overlord** | `SEGAofAmericaInc.Pa253b0c1Y` 1.0.0.6 | ✅ | fully playable | – |
| **Fortnite** | `436609B6.FortniteClient` 2.0.1461.7919 | ✅ | works fully, as far as the game allows without its online services | the game itself is online-only (multiplayer servers) |
| **XDefiant** | `Ubisoft.XDefiant-Game` 1.0.0.186 | ✅ | works fully, as far as the game allows without its servers | the game's own servers have been shut down |
| **A newer retail game** | – | 🚧 | starts in ~4 s, runs at a steady 30 fps without a crash, shows its menus and goes on past the first one to its settings; fits a 32 GB machine (~15 GB committed in the menus) | gameplay not reached yet; MS-in-AS routing needs runtime verification |

## Highlights

- **100 % of a retail game's shaders translate** – all 26 698 RDNA2 programs (26 503 records) of its shader pack
  become HLSL; random samples compile to DXIL with 0 errors.
- **The game's own console DLLs run on the PC** – its Bink 2 video codec decodes the game's
  movies, its ray-tracing BVH builder builds acceleration structures on a PC GPU, the AMD FSR 4
  console upscaler runs a whole frame on a PC GPU, the GDK HTTP library initialises.
- **Console textures decode exactly** – the GFX10 tiling and mip layout reproduce 909 of 912
  textures of the game's texture archive byte for byte, its volume textures included.
- **370+ automated tests**, including GPU tests that compare translated shaders against expected
  results instruction by instruction.

## What works

✅ done and verified

### Running the game's code

| Feature | State | What it does | Verified by |
|---|---|---|---|
| **PE loader** | ✅ | relocations, imports by name / ordinal / delay-load, TLS callbacks, exception tables, game DLLs, data-driven import routing (HLE / Windows / stub) | the game's 16 console DLLs load with 0 unresolved imports |
| **kernelx** | ✅ | title memory (budget from MicrosoftGame.Config, physical pages), threads on the PC's processors, modules, OS / console info | unit + end-to-end tests |
| **Memory** | ✅ | title graphics memory shared by CPU and GPU without copies, up to 16 GB (4 GiB windows) | GPU tests: loads, stores and atomics across windows |
| **File system** | ✅ | console paths (`GAME:`, `G:`, `D:` …) → the game folder; writes go to an overlay, the game folder is never modified; the console's drives: `S:\` (persistent local storage) and `T:\` (temp) in the title's data folder; free disk space answered for console paths | end-to-end: the test title's folder stays byte-identical; PLS and free space through the real call path |

### System services

| Feature | State | What it does | Verified by |
|---|---|---|---|
| **XGameRuntime** | ✅ | the GDK thunk protocol real titles use, laid out from a table of all 396 GDK runtime functions; offline XUser, XGameSave, persistent local storage, XPackage, XGame (title id), XSystem – the title sees an Xbox Series X / S; task queues, async, networking and dialogs through the PC's XGameRuntime | the game's libHttpClient initialises; users, saves and storage through the real call path; slot layout cross-checked against the game's own thunks |
| **Input** | ✅ | GameInput: one gamepad – the PC's XInput controller, and keyboard and mouse as a gamepad (see [Controls](#controls)) | unit tests; an Xbox controller in Minecraft |
| **Audio** | ✅ | XAudio2 → system XAudio2.9 (PCM / float voices; Opus 0x704F decoded via `MSOpusDecoder.dll`; XMA1 / XMA2 decoded in pure Rust) | unit + end-to-end tests |

### Graphics

| Feature | State | What it does | Verified by |
|---|---|---|---|
| **Shader recompiler** | ✅ | RDNA2 → HLSL → DXIL: VS, PS, CS, mesh (NGG), GS; atomics, LDS, scratch, images, samplers incl. static ones, wave ops, ray-tracing instructions; structured control flow; parallel DXC, disk cache | 26 698 / 26 698 programs of the retail pack; 0 DXC errors on random samples; per-instruction GPU tests |
| **Pipelines** | ✅ | PSOs from console shaders: VS+PS, CS, MS+PS, VS+GS+PS; root signature with the shaders' static samplers; non-blocking creation – a pipeline whose shaders are not compiled yet gets a stand-in at once and is built in the background | GPU tests drawing the game's own VS / PS pairs, also built in the background |
| **D3D12.X compute** | ✅ | console device slots, console descriptor heaps (T# / V# / S#), buffers at their console addresses, compute command lists recorded in the console format and replayed (tables, barriers, clears, copies) | the game's BVH builder and FSR 4 record and run through CGBJ |
| **D3D12.X graphics** | ✅ | device, resources and heaps (also placed in title memory), pipelines; the title's graphics command lists – draws, indirect draws, graphics root arguments, barriers, copies, clears – and command lists recorded by console code, replayed; `PresentX` and frame pacing into an CGBJ window | Minecraft Preview plays its worlds (millions of draws, none skipped); Fortnite and XDefiant draw their screens |
| **Textures** | ✅ | GFX10 tiling (all 14 2D swizzle modes, the 6 3D thick modes, linear), mip chains with mip tail, arrays, cubes and 3D textures → PC textures | 909 / 912 retail textures exact (the 3 volume LUTs decode smooth); GPU upload bit exact |
| **Ray tracing** | ✅ | BLAS / TLAS built on the GPU by the game's own XboxBvhBuilder; RDNA2 BVH node format; BVH intersection instructions emulated in shaders | GPU traversal = brute force reference; the game's builder output checked on the GPU |
| **Upscaling** | ✅ | the game's AMD FSR 4 console DLL (`amd_fidelityfx_upscaler_xbox.dll`): context, the 29 pipelines in the console driver's own container (FSPX) translated, a frame's 20 passes recorded and run on the GPU | end-to-end with the real DLL: a 1280×720 → 1920×1080 frame on an RX 9070, the input's gradient in the output |

Texture address layouts retain only one period of their high-coordinate lookup tables rather
than allocating a full 16-bit table for every axis. Address offsets are unchanged.
Flat pixel-shader parameters preserve integer selector bits; interpolated P2 results still use
floating-point conversion.
Reinitializing sparse GPU windows releases the previous state's resources after unlocking it,
avoiding a deadlock when those resources call back into sparse-buffer tracking.
Freed sparse blocks are decommitted before their addresses become available to other threads,
so a late decommit cannot discard a newly allocated block at the same address.
Texture uploads tolerate concurrent decommits outside the coherent window: readable pages are
copied through Windows' checked memory-read API, and unavailable pages remain zero-filled.
Idle tiled-texture pages are tracked in an expiry queue instead of scanning all active pages
at every placement. Stale entries for reused pages are ignored; idle retention and tile cooldown
remain two seconds each.
Compute PSOs whose driver build takes at least 250 ms keep their native driver blob in
`<DXIL cache>/driver` for reuse on later runs. `CGBJ_PSO_DISK_CACHE=0` disables this cache.
If the driver rejects a cached blob, CGBJ drops it and retries normal compilation; the
existing compute wait and compile-memory budget still apply. This cache does not cover
graphics pipeline state. Generated two-pass compute halves now use this cache too, with
their actual ABI root and static samplers. A rejected blob retries the native cold creation;
neither the compute pass nor the mesh pass is skipped. The mesh PSO remains separate.
Concurrent generated-compute creations with the same device, root, node, flags and native
cache path now share one in-flight gate. After the first cold result is published, waiting
callers re-read and validate the native blob. Distinct descriptors remain independent;
no PSO object, memory predicate or completion is substituted.
With `CGBJ_CRITICAL_PATH=1`, the first 16 sampled unclosed PSO-blocked recordings retain
Close, admission, native submission and reset transitions (256 lines, explicit exhaustion).
Unhandled access violations also capture bounded kernel-checked register memory and an
indexed-array candidate, with UMA window classification. Failed/partial reads stay unknown;
these local diagnostics do not repair pointers or change execution.
Offline `shaders --precompile --only CS --pipelines` also loads these native compute blobs
and saves newly built blobs only after native cached revalidation with the same ABI root.
It submits no GPU commands. Re-running reuses completed entries; compile, native creation or
cache persistence failures are reported with a nonzero exit status. Pipeline progress includes
DXIL identity, elapsed time and cache reuse. Console data and generated caches remain local.
`CGBJ_TRACE_PSO_ORDER=1` logs up to 128 paired worker/wait spans, including pipeline kind
and whether the waiting caller took the build itself. Matching keys identify concurrent
waits on one build. This changes logging only; it does not reorder, skip or time out work.
`CGBJ_TRACE_PSO_ORDER_AFTER=110` delays span admission until 110 seconds after log startup,
preserving the 128-span budget for a late stall. Earlier spans consume no budget. Missing,
negative or non-finite values use zero; both trace options leave execution policy unchanged.
`CGBJ_PERF_TRACE=1` with `CGBJ_ACTIVITY=1` samples OS memory budgets, working set, page-fault
count changes, process CPU usage in core equivalents, sparse-upload CPU phase totals, and
up to eight oldest live PSO build/wait spans every two seconds. Completed spans over one
second are logged separately. It has no lifetime span budget and does not skip or reorder
work. Page faults include soft faults; CPU phase sums are not GPU timestamps or frame time.
With the D3D12 debug layer enabled, `CGBJ_PERF_TRACE=1` also attaches scalar recording-call
metadata to ExecuteIndirect root-signature validation IDs 952/953. It identifies translated
and two-pass pipelines without changing their execution. Deferred callbacks on another thread
have no recording-call context; missing context does not identify a pipeline.
`CGBJ_PERF_TRACE=1` also logs the first eight two-pass ExecuteIndirect calls without requiring
the debug layer. By default these reach the native indirect path without an indirect compute
producer; the optional execution path described below supplies that producer.
CPU bottom-of-pipe writes outside unified memory wait for confirmed producer completion,
including after a ten-second warning. Pending writes retain their order on that queue while
independent queues can publish. Removed-device fences do not publish pending progress values.
Title `Map` calls on reserved resources and resources without CPU-visible heap pages use the
existing title-memory fallback directly. CGBJ does not issue the invalid native Map first;
UPLOAD, READBACK and CPU-visible custom heaps retain their native mapping path.
CGBJ remembers shader sets used by a run in `used-pipelines.txt` beside the shader cache.
On later runs it builds those lazy pipelines early on two to four low-priority workers;
unknown pipelines retain first-use compilation. `CGBJ_PSO_PRELOAD=0` disables early builds.
This requires an initial learning run and does not skip compute work or guarantee lower memory
use. Existing driver blobs are still validated and reused by the compute pipeline cache.
The local translated-shader cache uses a v2 namespace identified by GPU source files, target
and DXC toolchain. Runtime/HLE logging changes no longer invalidate translations. Legacy
EXE-keyed v1 entries remain on disk but are not imported; the first v2 use translates once.
DXIL and native driver caches keep their existing keys and validation. This reduces repeated
translation across compatible builds; it does not establish a game-load or FPS improvement.
`CGBJ_TWO_PASS_INDIRECT=1` enables experimental two-pass mesh indirect execution for a single
DISPATCH_MESH-only signature. It reads arguments and count on the GPU, runs the compute producer,
a UAV barrier and the mesh consumer. An explicitly checked record allocation starts at 32 MiB;
unsupported dimensions, multiple commands, root-changing signatures and insufficient capacity
are rejected and logged, never silently clamped. No first playable game scene is verified.
Indirect signature metadata follows successful creation and final Release, with generations
protecting reused addresses. Private GPU readback inspections retain their resources until
the producer fence completes. Completion logs audit GPU-generated dispatch arguments, not visual
correctness. Non-upload argument buffers follow the native INDIRECT_ARGUMENT state contract.
With performance tracing, the optional path logs entry and recording separately from GPU
completion. Mesh PSO rejection traces include DXBC checksums and scalar pipeline state, allowing
the failed creation to be distinguished from a command that never reached recording.
`CGBJ_CRITICAL_PATH=1` retains up to 8192 explicit counter-write, indirect recording and
submission events. On unresolved memory waits it reports the latest observed producer and
whether that recording reached native submission or was reset/released. Output is bounded;
eviction and unobserved shader stores prevent treating a missing producer as proof of absence.
Native submission is not fence completion. This trace does not alter scheduling or waits.
Lifecycle snapshots retain unique object/recording identities, native Close entry/result,
console replay entry, original-to-backing API admission, native Execute entry/return and queue
identity/type. Snapshots outlive verbose event eviction; expired snapshots are explicitly unknown.
The trace also preserves the count and first four external memory waits of each recording,
plus recent native queue Signal/Wait entry/result and completed-value samples. These distinguish
a producer with reverse dependencies from one safe to order as a whole; no fence is signalled
or memory predicate bypassed by the diagnostic.
With performance tracing, bounded checkpoints after 120s also join live recording PSO waits
to build/shader keys and query retained private CPU-write fences. Expired/reset/released
recordings are excluded. These fence samples cover their own submissions, not every GPU queue.
`CGBJ_ASYNC_MEMORY_WAITS=1` is an experimental submission path for full-mask GREATER_EQUAL
memory counters. A native queue wait returns control to the CPU; a bounded observer signals
its private fence only after the real CPU-visible predicates hold. Unreadable memory and timeouts
never release this gate. No game commands execute on the observer. Default scheduling is unchanged;
this does not implement waits at arbitrary positions inside a native command list.
`CGBJ_PSO_PRELOAD_KEYS=hexkey,hexkey` optionally limits speculative preload to at most64
known shader-set keys for a controlled scheduling comparison. Every other pipeline still
builds through its normal first use. Invalid lists preserve default preload behavior.
Focused preload logs start/result by shader and build key; it does not bypass compilation.
With `CGBJ_CRITICAL_PATH=1`, pipeline audit joins pending build/shader keys and worker/preload/
caller roles to exact compute native cache keys, hit/reject/cold outcomes and DXC enqueue,
dequeue, memory admission and compile spans. Recorded bindings are distinct from GPU execution.
Successful translated compute dispatch recordings keep up to256 PSO identities per list recording;
native submission logs these separately. Reset generations prevent attributing old work to a reused
list. Exceeding diagnostic bounds leaves coverage incomplete, never proves a missing execution.
The bounded dense checkpoint budget begins at the first unresolved memory predicate, so menu
time cannot consume scene diagnostics. No compile options or scheduling policy are changed.
Mesh pass-through shaders budget output vertices in DXC's 32-vertex chunks. Compact output
layouts are selected by the declaration's budget even when only one dispatch group is needed.
Console mesh shaders placed alone in the amplification-shader slot are routed as mesh shaders.
Their deferred stand-ins use a mesh pipeline and PC render-target/depth formats; compilation
can wait until binding instead of blocking each pipeline-creation call during startup.
Direct `DispatchMesh` runs translated console MS code as a compute pass, a UAV barrier,
and a pass-through mesh draw. Record buffers live until their command allocator resets.
This path supports one-dimensional groups within the PC dispatch limits and at most
128 MB of records; unsupported dimensions or sizes are logged and skipped. Two-pass
`ExecuteIndirect` mesh draws remain disabled unless explicitly enabled as described above.
DirectStorage keeps requests whose destination page table still contains zero pending
until the title calls `Submit`. At that call, only zero entries are refreshed; nonzero
entries retain their owned enqueue snapshots. Automatic half-full submissions recheck
readiness while holding the pending-queue lock.
The `cgbj` executable opts out of high-entropy address placement for console code with 40-bit
address fields. Dynamic-base ASLR and NX remain enabled; explicit top-down allocations are
not constrained by this linker setting.

`CGBJ_TRACE_DXC_INPUT=1` saves the exact HLSL and a `.compile.json` request beside each cache
miss in `CGBJ_DXIL_CACHE`, and logs compilation start/completion times. These are local shader
diagnostics, disabled by default. A request left without a completed DXIL can be compiled
outside the running title using the same compiler, entry point, profile and cache directory.

DirectStorage unpacks BCPack BC1, BC3, BC4, BC5, BC6H and BC7 streams, after zlib when requested.
BC2, unknown modes and hardware swizzling remain unsupported. `report.json` lists unpacked
and failed BCPack requests by mode. Synthetic decoder and request-path tests run without game
data; optional `CGBJ_SAMPLE_BCPACK` data exercises additional retail stream comparisons.

`CGBJ_DSTORAGE_FAILURE_DETAILS=1` logs bounded access-failure metadata (at most eight per
queue and 64 per process): failing stage, half-full automatic versus title submission, and
zero/total page counts. It records no addresses or contents and does not retry or reschedule
requests. Disabled by default.

### Media and tools

| Feature | State | What it does | Verified by |
|---|---|---|---|
| **Video** | ✅ | the game's Bink 2 console DLL decodes its movies (720p / 1080p) on the CPU; the game's own YUV → RGB display shaders (`PS_Bink…` in its pack) translate like any other. Bink's GPU-assisted mode needs no Bink-specific support: its compute shaders ship with the game and go through the recompiler too (no game seen using it yet) | a game movie decodes frame by frame, picture checked |
| **Tools** | ✅ | `cgbj inspect`, `cgbj run`, `cgbj disasm` (RDNA2, console shader containers), `cgbj shaders` (pack statistics, recompile / compile runs), `cgbj rpf`, `cgbj ttpf` (bounded RDS5 metadata probe) | – |

## Controls

A **gamepad is recommended**: console games are made for one, and their menus and controls expect it.

- **Gamepad:** any controller Windows sees through XInput (Xbox controllers, wired or wireless) is the
  game's gamepad – buttons, sticks, triggers and rumble. It can be plugged in or out while the game runs.
- **Keyboard and mouse** work too, as a gamepad: WASD the left stick, the mouse the right stick, mouse
  buttons the triggers, the wheel the bumpers, Enter / Space A, Escape / Backspace B, arrows the D-pad,
  E / Q Y / X, Shift / Ctrl the stick clicks, Tab View, P Menu. `keyboard_mouse` and `mouse_sensitivity` in
  the game's `cgbj.toml` turn it off or change the mouse speed. A gamepad and the keyboard / mouse can be
  used together.

## Building and usage

Windows 10/11 x64, Rust (`stable-x86_64-pc-windows-msvc`), the Windows SDK (DXC: `dxcompiler.dll`
+ `dxil.dll`, looked up in `Windows Kits\10\bin\<version>\x64`, next to `cgbj.exe` or in
`%CGBJ_DXC_DIR%`), a D3D12 GPU with Shader Model 6.6 and mesh shaders, and the system XGameRuntime
(`System32\xgameruntime.dll`, part of Windows / Gaming Services). On **Windows 10** (22H2
KB5029331+), inbox `D3D12Core.dll` stops at SM 6.5; place the Microsoft D3D12 Agility SDK
(`D3D12Core.dll`, plus `d3d12SDKLayers.dll` if using `CGBJ_D3D12_DEBUG=1`) in a `D3D12\` folder
next to `cgbj.exe`, directly next to `cgbj.exe`, in `%LOCALAPPDATA%\CGBJ\D3D12\`, or point `%CGBJ_D3D12_DIR%` at it
(for `cargo test`, use `%LOCALAPPDATA%\CGBJ\D3D12\` or `%CGBJ_D3D12_DIR%`).

- **DXC:** 1.8 or newer is recommended, from the
  [DirectXShaderCompiler releases](https://github.com/microsoft/DirectXShaderCompiler/releases): unpack one
  and point `CGBJ_DXC_DIR` at its `bin\x64`. A Windows SDK may hold an older one (the same `10.0.26100.0`
  folder has DXC 1.7.2308 or 1.8.2502, depending on the SDK's revision). DXC 1.7's DXIL was 2–2.7 times the
  size of 1.9's for translated compute programs and took an NVIDIA driver 1.4–2.2 times as long to build
  pipelines from ([#156](https://github.com/ivall/xcl/issues/156)). `cgbj run` prints the DXC it loaded, and
  `report.json` has it under `dxc`.
- **GPU:** developed on AMD RDNA4. The console's geometry and NGG programs run as a compute pass plus a
  mesh pass, so a GPU without mesh shaders draws none of them. On GPUs with 32-lane waves only
  (NVIDIA) console wave64 compute, geometry and mesh programs run as two 32-lane halves that exchange
  masks and lane values ([`docs/wave64-on-wave32.md`](docs/wave64-on-wave32.md)) – slower than
  64-lane waves, most for groups of several waves; wave64 vertex and pixel shaders that read lanes 32–63
  can still differ there. Test results on other GPUs: [#42](https://github.com/ivall/xcl/issues/42).

```powershell
cargo build --release --workspace          # target\release\cgbj.exe

cgbj inspect D:\Game\game.exe               # the game's imports and what CGBJ has for them
cgbj run D:\Game [-- game arguments]        # run
cgbj disasm <shader.bin> [--hex]            # RDNA2 disassembler (console containers too)
cgbj shaders D:\data\shaders.rpf --top 50   # pack statistics; --recomp / --compile N
cgbj rpf D:\data\shaders.rpf --extract NAME --out folder
cgbj ttpf D:\data\textures.ttpf --json       # bounded read-only RDS5 metadata probe
```

- **Shader compilation samples:** `cgbj shaders --compile N --json` lists the selected sample names,
  target profiles and HLSL byte counts in `recomp.dxc_samples`. The compile result covers those
  samples only; it does not establish compilation coverage of every stage or runtime correctness.
- **TTPF metadata:** `cgbj ttpf` reads only the 24-byte RDS5 prefix and 16-byte texture-table header,
  using the field interpretation from the existing texture test reader. It reports logical length,
  raw count fields and table bounds, without reading records or decompressing textures. Unknown
  options exit 2; unavailable, unsupported or truncated headers exit 3. A successful probe does not
  verify the payload, archive completeness, download progress or authenticity. Sparse files can
  contain missing data even when their logical length and these metadata fields look consistent.
- **Inspection errors:** `cgbj inspect` exits with code 3 for malformed PE optional headers, import,
  delay-import or TLS metadata and names the failed header or table on stderr. Declared optional
  headers must be present and contain their supported directory entries. Corrupt tables are not
  reported as absent, and no successful JSON report is emitted for them.
- **System DLL fallback** looks up Windows libraries by basename in System32 only, including their
  dependencies. It does not load a fallback provider from the current directory, PATH or an external
  absolute path. Game-shipped libraries continue to go through CGBJ's game loader.
- **Game DLL inspection** reads each provider's export metadata without loading its code. A file's
  presence alone does not satisfy an import: missing names, missing or null ordinals and unreadable
  export tables fall through to the remaining providers or are reported as stubs.
- **Without a command line** (cgbj.exe opened from Explorer) CGBJ shows a small menu: *Choose a
  game…* (pick its exe or `MicrosoftGame.config`) or *Run again* (the last one). On an error the
  window stays open until Enter.
- CGBJ works on **unpacked** game files you own; it contains nothing for decrypting or
  circumventing DRM.
- **The game folder is never modified** – writes go to the overlay.
- Every run writes `report.json` (called stubs, unknown D3D12.X slots and interfaces, XGameRuntime
  classes asked for, shader statistics, audio formats, crash).
  `d3d12.presents` counts presentations, not visible content. With `CGBJ_FRAME_DUMP=N` (`N > 1`),
  the existing optional frame dumps also set `d3d12.last_frame_dump`: the latest sampled frame's
  zero-based index, source dimensions, DXGI format, sample step, sample count and `non_dark_samples`
  (decoded 8-bit R+G+B > 30). The field is `null` until a frame is sampled; `non_dark_samples` is
  `null` if its format cannot be decoded. Intermediate render-target dumps do not update it.
  Sampling uses every fourth pixel in each direction (`CGBJ_FRAME_DUMP_FULL=1`: every pixel).
  A coarse sample can miss detail; a non-dark sample does not establish correct rendering or gameplay.
- Title data: `%LOCALAPPDATA%\CGBJ\<title>\` (`%CGBJ_DATA_ROOT%`): `cgbj.toml`, `overlay\`, `saves\`,
  `pls\` (the title's `S:\`), `temp\` (`T:\`), `cache\`, `logs\cgbj.log`, `logs\report.json` (the
  previous run's: `cgbj.prev.log`, `report.prev.json`).

## Tests

```powershell
.\scripts\test.ps1                         # cargo build --workspace + cargo test --workspace
```

Unit tests, an end-to-end test with our own "console title" (`tests/testtitle`) and GPU tests
(D3D12, SM 6.6; skipped without a GPU / DXC; `CGBJ_ADAPTER=1` or `CGBJ_ADAPTER=radeon` picks
another adapter than the first high-performance one, for titles too). A GPU test that cannot run on
the adapter (no GPU / DXC / wave64 / mesh shaders) passes too, but prints `SKIPPED <test>: <reason>`, and
`scripts/test.ps1` counts them at the end; `CGBJ_REQUIRE_GPU=wave64` (or `mesh`, or `wave64,mesh`) makes
those skips fail. Tests on real game data are opt-in through
environment variables pointing at your own files – `CGBJ_SAMPLE_RPF` (shader pack),
`CGBJ_SAMPLE_DLLS` (the game's console DLLs), `CGBJ_SAMPLE_TTPF` (texture archive),
`CGBJ_SAMPLE_BK2` (a movie), `CGBJ_SAMPLE_BVH4`, `CGBJ_SAMPLE_AWC` (a sound) – described in `HANDOFF.md`; without them those
tests pass without running anything (`scripts/test.ps1` lists the ones not set). No game data is
part of the repository.

## Licenses

**GPL-2.0-only** (`LICENSE`); third-party sources: `THIRD_PARTY.md` (including AMD's
machine-readable ISA, AMD addrlib swizzle patterns, LLVM disassembler tests, AnyPS5,
libHttpClient headers). WinDurango serves only as a reference – no code is ported from it. The
repository contains no headers or binaries from the console SDK.
