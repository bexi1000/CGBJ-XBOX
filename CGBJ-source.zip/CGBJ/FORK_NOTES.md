# CGBJ fork notes

Rebranding date: 2026-11-25.

CGBJ is a modified fork of XCL (https://github.com/ivall/xcl), not a clean-room or independently authored replacement. The supplied source is licensed GPL-2.0-only. The original license, third-party acknowledgments and upstream attribution remain in force. Contributors retain rights in their respective contributions; no assignment of copyright is asserted. Distribution must comply with all applicable licenses and permissions.

## Changes in this packaging pass

- Project-facing names, Rust crate and binary names, workspace paths, CLI references, environment variable prefixes, tests and scripts changed from XCL to CGBJ.
- An explicit game-specific executable name in the engineering handoff was generalized. General compatibility features and file-format implementations were preserved; this is not a removal of technical support for a particular title.
- Original upstream URLs and provenance notices retained. Inherited benchmarks and compatibility claims are distinguished from CGBJ verification.
- No new game assets, proprietary SDK material, or executable binaries added. Existing test fixtures remain unchanged.
- Dated change notices inserted in modified source and configuration files. File-level hashes are recorded in REBRAND_MANIFEST.json.

## Migration and verification

Use `cargo build --workspace` and `cargo test --workspace` on the supported Windows x64 environment with its required SDK and GPU. The output binary is `cgbj.exe`; the crate is `cgbj`; environment variables now use `CGBJ_`. Old XCL configuration and cache locations/keys may no longer be compatible. Do not assume existing caches will be reused. External launch scripts using the old names must be updated.

This is a source-level rebrand, not a new compatibility fix. The original test counts are historical; the rebranded tree has not been built or run in this environment. No claim is made that any particular game is playable.

Review THIRD_PARTY.md before publishing, including any upstream-specific third-party permissions.
