// Modified for the CGBJ fork on 2026-11-25: project branding and/or documentation. Original XCL and third-party notices remain applicable.
//! GPU side of CGBJ: console shader capture and the RDNA2 microcode toolchain
//! (decoder / disassembler – the front-end of the shader recompiler).

pub mod adapter;
pub mod agility;
pub mod bvh;
pub mod desc;
pub mod dxbc;
pub(crate) mod fence;
pub mod pack;
pub mod rdna2;
pub mod recomp;
mod rdna2_spec;
mod rdna2_xbox;
pub mod shader;
pub mod texture;
pub mod tiling;
mod tiling_tables;
pub mod uma;
pub mod xbox;

pub use rdna2_spec::ARCH as RDNA2_ARCH;
