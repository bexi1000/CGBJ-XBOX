// Modified for the CGBJ fork on 2026-11-25: project branding and/or documentation. Original XCL and third-party notices remain applicable.
//! Bounded read-only RDS5 metadata probing. Field interpretation follows the existing
//! TTPF test reader in gpu/texture.rs; no texture layout or payload is decoded here.

use std::fs::File;
use std::io::{Read, Seek, SeekFrom};
use std::path::Path;

use serde::Serialize;

const NOTICE: &str = "Interpreted metadata only; payload, archive completeness and authenticity are not verified. A sparse or downloading file may contain missing data.";

#[derive(Debug, Serialize)]
struct Probe {
    format: &'static str,
    logical_file_bytes: u64,
    index_count_field: u32,
    index_slots_before_table: u64,
    unpacked_stream_bytes: u64,
    texture_table_offset: u64,
    texture_count_field: u32,
    table_extent_within_file: bool,
    metadata_bytes_read: u32,
    payload_examined: bool,
    archive_complete_verified: bool,
    notice: &'static str,
}

fn probe(reader: &mut (impl Read + Seek), len: u64) -> Result<Probe, String> {
    let mut header = [0u8; 24];
    reader.read_exact(&mut header).map_err(|e| format!("RDS5 header: {e}"))?;
    if &header[..4] != b"RDS5" {
        return Err("RDS5 signature unavailable or unsupported; the file may be incomplete".into());
    }
    let word = |at| u32::from_le_bytes(header[at..at + 4].try_into().unwrap());
    let texture_table_offset = u64::from(word(16)) << 8;
    let table_header_end = texture_table_offset + 16; // offset is a shifted u32: cannot overflow u64
    if texture_table_offset < 24 || table_header_end > len {
        return Err("RDS5 table header is outside the logical file bounds".into());
    }
    reader.seek(SeekFrom::Start(texture_table_offset)).map_err(|e| format!("RDS5 table seek: {e}"))?;
    let mut table = [0u8; 16];
    reader.read_exact(&mut table).map_err(|e| format!("RDS5 table header: {e}"))?;
    let texture_count_field = u32::from_le_bytes(table[8..12].try_into().unwrap());
    // Counts can disagree with slot capacity in real headers; the legacy reader clamps them.
    // Expose both observations rather than treating this alone as proof of corruption.
    Ok(Probe {
        format: "RDS5",
        logical_file_bytes: len,
        index_count_field: word(4),
        index_slots_before_table: (texture_table_offset - 24) / 8,
        unpacked_stream_bytes: u64::from(word(8)) | (u64::from(word(12) & 0xff) << 32),
        texture_table_offset,
        texture_count_field,
        table_extent_within_file: table_header_end + u64::from(texture_count_field) * 16 <= len,
        metadata_bytes_read: 40,
        payload_examined: false,
        archive_complete_verified: false,
        notice: NOTICE,
    })
}

#[derive(Serialize)]
struct Out {
    file: String,
    #[serde(flatten)]
    metadata: Probe,
}

pub fn run(path: &Path, args: &[String]) -> i32 {
    let json = match args {
        [] => false,
        [flag] if flag == "--json" => true,
        _ => {
            eprintln!("cgbj ttpf: options must be empty or --json");
            return 2;
        }
    };
    let read = || -> Result<Probe, String> {
        let mut file = File::open(path).map_err(|e| e.to_string())?;
        let len = file.metadata().map_err(|e| e.to_string())?.len();
        probe(&mut file, len)
    };
    let metadata = match read() {
        Ok(p) => p,
        Err(e) => {
            eprintln!("cgbj ttpf: {}: {e}", path.display());
            return 3;
        }
    };
    if json {
        let out = Out { file: path.to_string_lossy().into_owned(), metadata };
        match serde_json::to_string_pretty(&out) {
            Ok(text) => println!("{text}"),
            Err(e) => {
                eprintln!("cgbj ttpf: JSON: {e}");
                return 3;
            }
        }
    } else {
        println!("TTPF/RDS5 metadata: {}", path.display());
        println!("Logical file bytes: {}", metadata.logical_file_bytes);
        println!("Index count field: {} (slots before table: {})", metadata.index_count_field, metadata.index_slots_before_table);
        println!("Unpacked stream bytes: {}", metadata.unpacked_stream_bytes);
        println!("Texture table offset: {:#x}", metadata.texture_table_offset);
        println!("Texture count field: {}", metadata.texture_count_field);
        println!("Declared table extent within logical file: {}", metadata.table_extent_within_file);
        println!("{}", metadata.notice);
    }
    0
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Cursor;

    fn fixture() -> Vec<u8> {
        let mut data = vec![0u8; 0x140];
        data[..4].copy_from_slice(b"RDS5");
        data[4..8].copy_from_slice(&4u32.to_le_bytes());
        data[8..12].copy_from_slice(&0x12345000u32.to_le_bytes());
        data[12..16].copy_from_slice(&0x16000002u32.to_le_bytes());
        data[16..20].copy_from_slice(&1u32.to_le_bytes());
        data[0x108..0x10c].copy_from_slice(&2u32.to_le_bytes());
        data
    }

    #[test]
    fn interpreted_fields_do_not_claim_payload_validation() {
        let p = probe(&mut Cursor::new(fixture()), 0x140).unwrap();
        assert_eq!((p.index_count_field, p.index_slots_before_table), (4, 29));
        assert_eq!(p.unpacked_stream_bytes, 0x212345000);
        assert_eq!(p.texture_count_field, 2);
        assert!(p.table_extent_within_file);
        assert!(!p.payload_examined && !p.archive_complete_verified);
    }

    #[test]
    fn short_headers_and_tables_return_errors() {
        let data = fixture();
        for n in 0..24 {
            assert!(probe(&mut Cursor::new(&data[..n]), 0x140).is_err(), "prefix {n}");
        }
        for n in 0..16 {
            assert!(probe(&mut Cursor::new(&data[..0x100 + n]), 0x140).is_err(), "table {n}");
        }
    }

    #[test]
    fn unsupported_and_unavailable_signatures_return_errors() {
        for magic in [*b"RDS4", [0; 4], *b"MZ!!"] {
            let mut data = fixture();
            data[..4].copy_from_slice(&magic);
            assert!(probe(&mut Cursor::new(data), 0x140).unwrap_err().contains("signature"));
        }
    }

    #[test]
    fn table_header_outside_logical_length_is_rejected_before_seek() {
        for (offset, len) in [(0, 0x140), (1, 0x10f), (u32::MAX, 210 << 30)] {
            let mut data = fixture();
            data[16..20].copy_from_slice(&offset.to_le_bytes());
            let mut reader = Cursor::new(data);
            assert!(probe(&mut reader, len).unwrap_err().contains("bounds"));
            assert_eq!(reader.position(), 24);
        }
    }

    #[test]
    fn counts_larger_than_available_slots_are_observations_not_allocations() {
        let mut data = fixture();
        data[4..8].copy_from_slice(&u32::MAX.to_le_bytes());
        data[0x108..0x10c].copy_from_slice(&u32::MAX.to_le_bytes());
        let p = probe(&mut Cursor::new(data), 0x140).unwrap();
        assert_eq!(p.index_count_field, u32::MAX);
        assert_eq!(p.texture_count_field, u32::MAX);
        assert!(!p.table_extent_within_file);
    }

    #[test]
    fn a_210_gib_logical_file_requires_only_40_bytes_even_with_short_reads() {
        struct Meter {
            data: Cursor<Vec<u8>>,
            bytes: usize,
            seeks: Vec<SeekFrom>,
        }
        impl Read for Meter {
            fn read(&mut self, buf: &mut [u8]) -> std::io::Result<usize> {
                let n = buf.len().min(3);
                let read = self.data.read(&mut buf[..n])?;
                self.bytes += read;
                assert!(self.bytes <= 40, "probe read payload or index records");
                Ok(read)
            }
        }
        impl Seek for Meter {
            fn seek(&mut self, pos: SeekFrom) -> std::io::Result<u64> {
                self.seeks.push(pos);
                self.data.seek(pos)
            }
        }
        let mut reader = Meter { data: Cursor::new(fixture()), bytes: 0, seeks: Vec::new() };
        let p = probe(&mut reader, 210 << 30).unwrap();
        assert_eq!(reader.bytes, 40);
        assert_eq!(reader.seeks, [SeekFrom::Start(0x100)]);
        assert_eq!(p.logical_file_bytes, 210 << 30);
        assert_eq!(p.metadata_bytes_read, 40);
    }
}
