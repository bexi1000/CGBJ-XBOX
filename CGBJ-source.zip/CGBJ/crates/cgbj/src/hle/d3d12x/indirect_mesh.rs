//! GPU argument preparation shared by opt-in two-pass mesh execution and its tests.

use std::ffi::c_void;
use std::mem::ManuallyDrop;
use windows::core::Interface;
use windows::Win32::Graphics::Direct3D12::*;

/// Output: compute XYZ, mesh XYZ, status (0 OK, 1 dimensions, 2 capacity), raw input XYZ.
pub(crate) const OUTPUT_BYTES: u64 = 40;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct Plan {
    capacity_groups: u32,
    split: u32,
    max_commands: u32,
}

impl Plan {
    /// Capacity is explicit: never silently clamp a requested record allocation.
    pub(crate) fn new(record_dwords: u64, record_bytes: u64, split: u32, max_commands: u32) -> Result<Self, String> {
        if max_commands > 1 { return Err("multiple two-pass indirect commands need separate records".into()); }
        if record_bytes > 128 << 20 || split == 0 || split > 65535 || record_dwords == 0 {
            return Err("invalid two-pass indirect record budget or split".into());
        }
        let stride = record_dwords.checked_mul(4).ok_or("record stride overflow")?;
        let capacity = (record_bytes / stride).min((65535 / split) as u64);
        if capacity == 0 { return Err("no complete mesh record fits".into()); }
        Ok(Self { capacity_groups: capacity as u32, split, max_commands })
    }
}

const PREPARE: &str = r#"
cbuffer C : register(b0) { uint argOffset; uint countOffset; uint capacity; uint split; uint hasCount; uint maximum; };
ByteAddressBuffer arguments : register(t0);
ByteAddressBuffer counts : register(t1);
RWByteAddressBuffer output : register(u0);
[numthreads(1,1,1)]
void main() {
    uint3 producer = uint3(0,0,0), mesh = uint3(0,0,0), raw = uint3(0,0,0);
    uint status = 0;
    if (maximum != 0 && (hasCount == 0 || counts.Load(countOffset) != 0)) {
        uint3 groups = arguments.Load3(argOffset);
        raw = groups;
        if (all(groups != 0)) {
            if (groups.y != 1 || groups.z != 1) status = 1;
            else if (groups.x > capacity) status = 2;
            else { producer = groups; mesh = uint3(groups.x * split,1,1); }
        }
    }
    output.Store3(0, producer);
    output.Store3(12, mesh);
    output.Store(24, status);
    output.Store3(28, raw);
}
"#;

pub(crate) struct Pipeline {
    root: ID3D12RootSignature,
    pso: ID3D12PipelineState,
}

impl Pipeline {
    pub(crate) unsafe fn new(device: &ID3D12Device) -> Result<Self, String> {
        let descriptor = |kind, register| D3D12_ROOT_PARAMETER {
            ParameterType: kind,
            Anonymous: D3D12_ROOT_PARAMETER_0 { Descriptor: D3D12_ROOT_DESCRIPTOR { ShaderRegister: register, RegisterSpace: 0 } },
            ShaderVisibility: D3D12_SHADER_VISIBILITY_ALL,
        };
        let params = [
            D3D12_ROOT_PARAMETER { ParameterType: D3D12_ROOT_PARAMETER_TYPE_32BIT_CONSTANTS,
                Anonymous: D3D12_ROOT_PARAMETER_0 { Constants: D3D12_ROOT_CONSTANTS { ShaderRegister: 0, RegisterSpace: 0, Num32BitValues: 6 } },
                ShaderVisibility: D3D12_SHADER_VISIBILITY_ALL },
            descriptor(D3D12_ROOT_PARAMETER_TYPE_SRV, 0), descriptor(D3D12_ROOT_PARAMETER_TYPE_SRV, 1),
            descriptor(D3D12_ROOT_PARAMETER_TYPE_UAV, 0),
        ];
        let desc = D3D12_ROOT_SIGNATURE_DESC { NumParameters: params.len() as u32, pParameters: params.as_ptr(), ..Default::default() };
        let mut blob = None;
        D3D12SerializeRootSignature(&desc, D3D_ROOT_SIGNATURE_VERSION_1, &mut blob, None).map_err(|e| e.to_string())?;
        let blob = blob.ok_or("no indirect preparation root signature")?;
        let root: ID3D12RootSignature = device.CreateRootSignature(0,
            std::slice::from_raw_parts(blob.GetBufferPointer() as *const u8, blob.GetBufferSize())).map_err(|e| e.to_string())?;
        let dxil = crate::gpu::recomp::dxc::compile_cached(PREPARE, "main", "cs_6_0")?.0;
        let mut desc = D3D12_COMPUTE_PIPELINE_STATE_DESC {
            pRootSignature: ManuallyDrop::new(Some(root.clone())),
            CS: D3D12_SHADER_BYTECODE { pShaderBytecode: dxil.as_ptr() as *const c_void, BytecodeLength: dxil.len() },
            ..Default::default()
        };
        let pso = device.CreateComputePipelineState(&desc).map_err(|e| e.to_string());
        ManuallyDrop::drop(&mut desc.pRootSignature);
        Ok(Self { root, pso: pso? })
    }

    /// Inputs must already be NON_PIXEL_SHADER_RESOURCE (or a compatible read state), output UAV.
    /// Caller must add the output barrier and inspect status before treating work as successful.
    pub(crate) unsafe fn validate_buffers(
        args: &ID3D12Resource, args_offset: u64, counts: Option<(&ID3D12Resource, u64)>, output: &ID3D12Resource,
    ) -> Result<(u32, u32, u32), String> {
        let check = |resource: &ID3D12Resource, offset: u64, bytes: u64| -> Result<u32, String> {
            let d = resource.GetDesc();
            if d.Dimension != D3D12_RESOURCE_DIMENSION_BUFFER || offset % 4 != 0 || offset > u32::MAX as u64
                || offset.checked_add(bytes).is_none_or(|end| end > d.Width) {
                return Err("indirect preparation buffer range is invalid".into());
            }
            Ok(offset as u32)
        };
        let arg_offset = check(args, args_offset, 12)?;
        let (count, count_offset, has_count) = match counts {
            Some((r, offset)) => (r, check(r, offset, 4)?, 1),
            None => (args, 0, 0),
        };
        check(output, 0, OUTPUT_BYTES)?;
        if args.as_raw() == output.as_raw() || count.as_raw() == output.as_raw() {
            return Err("indirect preparation input aliases output".into());
        }
        if output.GetDesc().Flags & D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS == D3D12_RESOURCE_FLAG_NONE {
            return Err("indirect preparation output has no UAV support".into());
        }
        Ok((arg_offset, count_offset, has_count))
    }

    pub(crate) unsafe fn record(&self, list: &ID3D12GraphicsCommandList, plan: Plan,
        args: &ID3D12Resource, args_offset: u64, counts: Option<(&ID3D12Resource, u64)>, output: &ID3D12Resource,
    ) -> Result<(), String> {
        let (arg_offset, count_offset, has_count) = Self::validate_buffers(args, args_offset, counts, output)?;
        let count = counts.map_or(args, |(r, _)| r);
        let constants = [arg_offset, count_offset, plan.capacity_groups, plan.split, has_count, plan.max_commands];
        list.SetComputeRootSignature(&self.root);
        list.SetPipelineState(&self.pso);
        list.SetComputeRoot32BitConstants(0, constants.len() as u32, constants.as_ptr() as *const c_void, 0);
        list.SetComputeRootShaderResourceView(1, args.GetGPUVirtualAddress());
        list.SetComputeRootShaderResourceView(2, count.GetGPUVirtualAddress());
        list.SetComputeRootUnorderedAccessView(3, output.GetGPUVirtualAddress());
        list.Dispatch(1, 1, 1);
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn plans_refuse_unsupported_commands_and_unrepresentable_records() {
        assert!(Plan::new(8, 256, 3, 2).is_err());
        assert!(Plan::new(u64::MAX, 256, 1, 1).is_err());
        assert!(Plan::new(8, (128 << 20) + 1, 1, 1).is_err());
        assert!(Plan::new(0, 256, 1, 1).is_err());
        assert!(Plan::new(8, 31, 1, 1).is_err());
        assert!(Plan::new(8, 256, 0, 1).is_err());
        assert!(Plan::new(8, 256, 65536, 1).is_err());
        assert_eq!(Plan::new(1, 128 << 20, 3, 1).unwrap().capacity_groups, 21845);
    }

    unsafe fn transition(list: &ID3D12GraphicsCommandList, r: &ID3D12Resource, before: D3D12_RESOURCE_STATES, after: D3D12_RESOURCE_STATES) {
        let mut barrier = D3D12_RESOURCE_BARRIER { Type: D3D12_RESOURCE_BARRIER_TYPE_TRANSITION,
            Anonymous: D3D12_RESOURCE_BARRIER_0 { Transition: ManuallyDrop::new(D3D12_RESOURCE_TRANSITION_BARRIER {
                pResource: ManuallyDrop::new(Some(r.clone())), Subresource: D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, StateBefore: before, StateAfter: after }) },
            ..Default::default() };
        list.ResourceBarrier(&[std::ptr::read(&barrier)]);
        ManuallyDrop::drop(&mut (*barrier.Anonymous.Transition).pResource);
    }

    /// Inputs arrive through GPU copies after recording. CPU guesses cannot satisfy this test.
    #[test]
    fn gpu_prepares_execution_time_counts_dimensions_and_capacity_without_clamping() {
        unsafe {
            let Ok(dev) = crate::gpu::agility::create_device(None, windows::Win32::Graphics::Direct3D::D3D_FEATURE_LEVEL_11_0) else {
                return crate::gpu::recomp::runner::skip_test("no D3D12 GPU");
            };
            let pipeline = Pipeline::new(&dev).expect("preparation pipeline");
            let q: ID3D12CommandQueue = dev.CreateCommandQueue(&D3D12_COMMAND_QUEUE_DESC::default()).unwrap();
            let alloc: ID3D12CommandAllocator = dev.CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT).unwrap();
            let list: ID3D12GraphicsCommandList = dev.CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, &alloc, None).unwrap();
            // x,y,z,count,has-count,maximum -> computeXYZ,meshXYZ,status
            let cases: [([u32;6],[u32;7]);8] = [
                ([7,1,1,1,1,1], [7,1,1,21,1,1,0]),
                ([9,1,1,0,1,1], [0,0,0,0,0,0,0]),
                ([7,0,1,1,1,1], [0,0,0,0,0,0,0]),
                ([9,1,1,1,1,1], [0,0,0,0,0,0,2]),
                ([7,2,1,1,1,1], [0,0,0,0,0,0,1]),
                ([7,1,1,0,0,1], [7,1,1,21,1,1,0]),
                ([7,1,1,2,1,1], [7,1,1,21,1,1,0]),
                ([7,1,1,1,1,0], [0,0,0,0,0,0,0]),
            ];
            let buffer = |heap, bytes, flags, state| {
                let d = D3D12_RESOURCE_DESC { Dimension: D3D12_RESOURCE_DIMENSION_BUFFER, Width: bytes, Height: 1,
                    DepthOrArraySize: 1, MipLevels: 1, SampleDesc: windows::Win32::Graphics::Dxgi::Common::DXGI_SAMPLE_DESC { Count: 1, Quality: 0 },
                    Layout: D3D12_TEXTURE_LAYOUT_ROW_MAJOR, Flags: flags, ..Default::default() };
                let mut r: Option<ID3D12Resource> = None;
                dev.CreateCommittedResource(&D3D12_HEAP_PROPERTIES { Type: heap, ..Default::default() }, D3D12_HEAP_FLAG_NONE, &d, state, None, &mut r).unwrap();
                r.unwrap()
            };
            let input = buffer(D3D12_HEAP_TYPE_DEFAULT, 64, D3D12_RESOURCE_FLAG_NONE, D3D12_RESOURCE_STATE_COPY_DEST);
            let upload = buffer(D3D12_HEAP_TYPE_UPLOAD, cases.len() as u64 * 64, D3D12_RESOURCE_FLAG_NONE, D3D12_RESOURCE_STATE_GENERIC_READ);
            let output = buffer(D3D12_HEAP_TYPE_DEFAULT, 64, D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
            let readback = buffer(D3D12_HEAP_TYPE_READBACK, cases.len() as u64 * 64, D3D12_RESOURCE_FLAG_NONE, D3D12_RESOURCE_STATE_COPY_DEST);
            let mut p = std::ptr::null_mut();
            upload.Map(0, None, Some(&mut p)).unwrap();
            std::ptr::write_bytes(p, 0, cases.len() * 64);
            for (i, (c, _)) in cases.iter().enumerate() {
                let words = (p as *mut u32).add(i * 16);
                std::ptr::copy_nonoverlapping(c.as_ptr(), words.add(4), 3);
                *words.add(8) = c[3];
            }
            upload.Unmap(0, None);
            for (i, (c, _)) in cases.iter().enumerate() {
                if i != 0 {
                    transition(&list, &input, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_DEST);
                    transition(&list, &output, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
                }
                list.CopyBufferRegion(&input, 0, &upload, i as u64 * 64, 64);
                transition(&list, &input, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
                let plan = Plan::new(8, 256, 3, c[5]).unwrap();
                pipeline.record(&list, plan, &input, 16, (c[4] != 0).then_some((&input, 32)), &output).unwrap();
                transition(&list, &output, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_COPY_SOURCE);
                list.CopyBufferRegion(&readback, i as u64 * 64, &output, 0, OUTPUT_BYTES);
            }
            list.Close().unwrap();
            q.ExecuteCommandLists(&[Some(list.cast().unwrap())]);
            crate::gpu::texture::wait(&dev, &q).unwrap();
            readback.Map(0, None, Some(&mut p)).unwrap();
            let actual: Vec<[u32;7]> = (0..cases.len()).map(|i| *(p as *const [u32;16]).add(i).cast::<[u32;7]>()).collect();
            let oversized_input = std::slice::from_raw_parts((p as *const u32).add(3 * 16 + 7), 3).to_vec();
            readback.Unmap(0, None);
            for (i, (_, expected)) in cases.iter().enumerate() { assert_eq!(actual[i], *expected, "GPU case {i}"); }
            assert_eq!(oversized_input, [9,1,1], "rejected groups remain available for diagnosis");
        }
    }
}
