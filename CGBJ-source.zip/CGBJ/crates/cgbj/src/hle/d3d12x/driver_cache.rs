// Modified for the CGBJ fork on 2026-11-25: project branding and/or documentation. Original XCL and third-party notices remain applicable.
//! Compute driver blobs between runs. Adapted from XCL PR634, head9182f275 (GPL-2.0-only).
//! https://github.com/ivall/xcl/pull/634
//! A rejected blob always retries a cold build.

use std::io::Read;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex, OnceLock, Weak};

#[derive(Hash, PartialEq, Eq)]
struct FlightKey { path: PathBuf, device: usize, root: usize, node: u32, flags: i32 }

/// Only identical native descriptors wait on one another. No PSO object or completion is
/// shared: every caller still creates and validates its own native cached pipeline.
pub(super) fn native_flight(path: Option<&Path>, device: usize, root: usize, node: u32, flags: i32) -> Option<Arc<Mutex<()>>> {
    static FLIGHTS: OnceLock<Mutex<std::collections::HashMap<FlightKey, Weak<Mutex<()>>>>> = OnceLock::new();
    let path = path?;
    let key = FlightKey { path: path.into(), device, root, node, flags };
    let mut map = FLIGHTS.get_or_init(|| Mutex::new(Default::default())).lock().unwrap();
    if let Some(gate) = map.get(&key).and_then(Weak::upgrade) { return Some(gate); }
    if map.len() >= 256 { map.retain(|_, v| v.strong_count() != 0); }
    if map.len() >= 256 { return None; }
    let gate = Arc::new(Mutex::new(()));
    map.insert(key, Arc::downgrade(&gate));
    Some(gate)
}

pub(super) const KEEP: std::time::Duration = std::time::Duration::from_millis(250);
pub(super) const MAX_BLOB: u64 = 128 << 20;
static HITS: AtomicU64 = AtomicU64::new(0);
static STALE: AtomicU64 = AtomicU64::new(0);
static STORED: AtomicU64 = AtomicU64::new(0);

pub(super) fn name(dxil: &[u8], flags: i32) -> String {
    format!("{:016x}-{:x}-{:x}.pso", crate::gpu::shader::fnv64(dxil), dxil.len(), flags)
}

pub(super) fn path(dxil: &[u8], flags: i32) -> Option<PathBuf> {
    static ON: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    ON.get_or_init(|| std::env::var("CGBJ_PSO_DISK_CACHE").map_or(true, |v| v.trim() != "0"))
        .then(|| crate::gpu::recomp::dxc::cache_dir().join("driver").join(name(dxil, flags)))
}

pub(super) fn load(p: &Path) -> Option<Vec<u8>> {
    let file = std::fs::File::open(p).ok()?;
    let size = file.metadata().ok()?.len();
    if size == 0 || size > MAX_BLOB {
        return None;
    }
    let mut bytes = Vec::new();
    bytes.try_reserve_exact(size as usize).ok()?;
    file.take(MAX_BLOB + 1).read_to_end(&mut bytes).ok()?;
    (!bytes.is_empty() && bytes.len() as u64 <= MAX_BLOB).then_some(bytes)
}

fn note(ok: bool, p: &Path) {
    if ok {
        let n = HITS.fetch_add(1, Ordering::Relaxed) + 1;
        if n.is_power_of_two() {
            crate::xlog_info!("D3D12.X: {n} compute pipelines reused from driver blobs on disk");
        }
    } else {
        let _ = std::fs::remove_file(p);
        if STALE.fetch_add(1, Ordering::Relaxed) == 0 {
            crate::xlog_info!("D3D12.X: a cached driver blob was rejected; retrying a cold build");
        }
    }
}

/// The caller owns the descriptor, device, and HRESULT policy. Cached bytes only live
/// during a build call. Failure with a blob is retried once without it, never skipped.
pub(super) fn build<T, E>(p: Option<&Path>, mut make: impl FnMut(Option<&[u8]>) -> Result<T, E>) -> Result<(T, bool), E> {
    let key = || p.and_then(Path::file_name).map_or_else(|| "disabled".into(), |s| s.to_string_lossy().into_owned());
    if let Some(p) = p {
        if let Some(bytes) = load(p) {
            super::super::pipeline_audit::event("cache-try", format_args!("key={}", key()));
            let _span = super::super::pipeline_audit::span("native-cached", key);
            match make(Some(&bytes)) {
                Ok(value) => { super::super::pipeline_audit::event("cache-hit", format_args!("key={}", key())); note(true, p); return Ok((value, true)); }
                Err(_) => { super::super::pipeline_audit::event("cache-reject", format_args!("key={}", key())); note(false, p); }
            }
        }
    }
    super::super::pipeline_audit::event("cache-cold", format_args!("key={}", key()));
    let _span = super::super::pipeline_audit::span("native-cold", key);
    make(None).map(|value| (value, false))
}

pub(super) fn write(p: &Path, bytes: &[u8]) -> bool {
    if bytes.is_empty() || bytes.len() as u64 > MAX_BLOB {
        return false;
    }
    let Some(dir) = p.parent() else { return false };
    if std::fs::create_dir_all(dir).is_err() {
        return false;
    }
    static NEXT: AtomicU64 = AtomicU64::new(0);
    let tmp = p.with_extension(format!("tmp{}-{}", std::process::id(), NEXT.fetch_add(1, Ordering::Relaxed)));
    let ok = std::fs::write(&tmp, bytes).is_ok() && std::fs::rename(&tmp, p).is_ok();
    if !ok {
        let _ = std::fs::remove_file(&tmp);
    }
    ok
}

pub(super) fn keep(p: &Path, blob: &[u8], took: std::time::Duration) {
    if took >= KEEP && write(p, blob) {
        let n = STORED.fetch_add(1, Ordering::Relaxed) + 1;
        if n.is_power_of_two() {
            crate::xlog_info!("D3D12.X: {n} driver blobs saved (latest build {} ms, {} KB)", took.as_millis(), blob.len() >> 10);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn concurrent_identical_misses_have_one_cold_build() {
        use std::sync::{Barrier, atomic::AtomicUsize};
        let dir = test_dir(); let path = dir.join("single-flight.pso");
        let attempts = AtomicUsize::new(0); let cold = AtomicUsize::new(0);
        let start = Barrier::new(4);
        std::thread::scope(|s| {
            for _ in 0..4 {
                s.spawn(|| {
                    start.wait(); attempts.fetch_add(1, Ordering::SeqCst);
                    let gate = native_flight(Some(&path), 0x7101, 0x7102, 0, 0).unwrap();
                    let _held = gate.lock().unwrap();
                    build::<_, ()>(Some(&path), |bytes| {
                        if let Some(b) = bytes { assert_eq!(b, b"owned driver blob"); }
                        else {
                            cold.fetch_add(1, Ordering::SeqCst);
                            while attempts.load(Ordering::SeqCst) != 4 { std::thread::yield_now(); }
                            assert!(write(&path, b"owned driver blob"));
                        }
                        Ok(())
                    }).unwrap();
                });
            }
        });
        assert_eq!(cold.load(Ordering::SeqCst), 1, "same-key callers compiled concurrently before the cache was published");
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn native_flight_preserves_descriptor_identity_and_independent_progress() {
        let p = std::path::Path::new("owned-independent-flight.pso");
        let a = native_flight(Some(p), 0x7201, 0x7202, 0, 0).unwrap();
        let same = native_flight(Some(p), 0x7201, 0x7202, 0, 0).unwrap();
        assert!(Arc::ptr_eq(&a, &same));
        let held = a.lock().unwrap();
        assert!(same.try_lock().is_err());
        for (dev,root,node,flags) in [(0x7203,0x7202,0,0),(0x7201,0x7203,0,0),(0x7201,0x7202,1,0),(0x7201,0x7202,0,1)] {
            let other = native_flight(Some(p), dev, root, node, flags).unwrap();
            assert!(!Arc::ptr_eq(&a, &other));
            assert!(other.try_lock().is_ok(), "unrelated native creation blocked on a different descriptor");
        }
        drop(held);
        assert!(same.try_lock().is_ok());
        assert!(native_flight(None,0,0,0,0).is_none());
    }

    fn test_dir() -> PathBuf {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        std::env::temp_dir().join(format!("cgbj-driver-cache-{}-{}", std::process::id(), NEXT.fetch_add(1, Ordering::Relaxed)))
    }

    #[test]
    fn driver_cache_keys_and_atomic_file_roundtrip() {
        assert_ne!(name(b"abc", 0), name(b"abd", 0));
        assert_ne!(name(b"abc", 0), name(b"abc", 1));
        assert!(name(&[0u8; 0x1234], 2).ends_with("-1234-2.pso"));
        let dir = test_dir();
        let p = dir.join("driver").join(name(b"program", 0));
        assert!(load(&p).is_none());
        assert!(!write(&p, &[]));
        keep(&p, &[1, 2, 3], std::time::Duration::from_millis(10));
        assert!(load(&p).is_none());
        keep(&p, &[1, 2, 3], std::time::Duration::from_secs(1));
        assert_eq!(load(&p).unwrap(), [1, 2, 3]);
        assert_eq!(std::fs::read_dir(p.parent().unwrap()).unwrap().count(), 1);
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn rejected_driver_blob_retries_without_it_and_preserves_cold_errors() {
        let dir = test_dir();
        let p = dir.join("driver.pso");
        assert!(write(&p, &[1, 2, 3]));
        assert_eq!(build::<_, ()>(Some(&p), |blob| Ok(blob.unwrap().len())), Ok((3, true)));
        let mut calls = Vec::new();
        let result = build(Some(&p), |blob| {
            calls.push(blob.map(|b| b.to_vec()));
            if blob.is_some() { Err(-1i32) } else { Ok(42) }
        });
        assert_eq!(result, Ok((42, false)));
        assert_eq!(calls, [Some(vec![1, 2, 3]), None]);
        assert!(!p.exists());
        assert!(write(&p, &[7]));
        let mut calls = 0;
        assert_eq!(build::<(), _>(Some(&p), |_| { calls += 1; Err(-2i32) }), Err(-2));
        assert_eq!(calls, 2);
        assert!(!p.exists());
        assert_eq!(build::<(), _>(None, |_| Err(-3i32)), Err(-3));
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn concurrent_driver_blob_writers_leave_one_complete_file() {
        let dir = test_dir();
        let p = dir.join("driver.pso");
        std::thread::scope(|s| {
            for value in 1u8..=4 {
                let p = &p;
                s.spawn(move || { write(p, &vec![value; 65536]); });
            }
        });
        let got = load(&p).unwrap();
        assert_eq!(got.len(), 65536);
        assert!(got.iter().all(|&b| b == got[0]));
        assert!((1..=4).contains(&got[0]));
        assert_eq!(std::fs::read_dir(&dir).unwrap().count(), 1);
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn empty_and_oversized_driver_blobs_are_cache_misses() {
        let dir = test_dir();
        std::fs::create_dir_all(&dir).unwrap();
        let p = dir.join("driver.pso");
        let file = std::fs::File::create(&p).unwrap();
        assert!(load(&p).is_none());
        file.set_len(MAX_BLOB + 1).unwrap();
        assert!(load(&p).is_none());
        drop(file);
        let mut calls = 0;
        assert_eq!(build::<_, ()>(Some(&p), |blob| { calls += 1; assert!(blob.is_none()); Ok(9) }), Ok((9, false)));
        assert_eq!(calls, 1);
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn gpu_driver_blob_roundtrip_creates_a_native_compute_pipeline() {
        use windows::core::Interface;
        use windows::Win32::Graphics::Direct3D::*;
        use windows::Win32::Graphics::Direct3D12::*;
        unsafe {
            let mut dev: Option<ID3D12Device> = None;
            if D3D12CreateDevice(None, D3D_FEATURE_LEVEL_11_0, &mut dev).is_err() {
                crate::gpu::recomp::runner::skip_test("no GPU");
                return;
            }
            let dev = dev.unwrap();
            let mut ser = None;
            D3D12SerializeRootSignature(&D3D12_ROOT_SIGNATURE_DESC::default(), D3D_ROOT_SIGNATURE_VERSION_1, &mut ser, None).unwrap();
            let ser = ser.unwrap();
            let rs: ID3D12RootSignature = dev.CreateRootSignature(0, std::slice::from_raw_parts(ser.GetBufferPointer() as *const u8, ser.GetBufferSize())).unwrap();
            let cs = super::super::dummy_cs_bytecode();
            let make = |cached: Option<&[u8]>| {
                let mut desc = D3D12_COMPUTE_PIPELINE_STATE_DESC {
                    pRootSignature: std::mem::ManuallyDrop::new(Some(rs.clone())),
                    CS: D3D12_SHADER_BYTECODE { pShaderBytecode: cs.as_ptr() as _, BytecodeLength: cs.len() },
                    CachedPSO: cached.map_or(D3D12_CACHED_PIPELINE_STATE::default(), |b| D3D12_CACHED_PIPELINE_STATE { pCachedBlob: b.as_ptr() as _, CachedBlobSizeInBytes: b.len() }),
                    ..Default::default()
                };
                let raw_dev = dev.as_raw();
                let entry = if super::super::is_adopted(raw_dev) {
                    super::super::orig_fn(raw_dev, super::super::slot_of(raw_dev, "CreateComputePipelineState"))
                } else { *(*(raw_dev as *const *const usize)).add(11) };
                let native: super::super::PsoFn = std::mem::transmute(entry);
                let mut raw = std::ptr::null_mut();
                let hr = native(raw_dev, &desc as *const _ as _, &super::super::pc_iid(super::super::Kind::PipelineState), &mut raw);
                let result: windows::core::Result<ID3D12PipelineState> = if hr < 0 {
                    Err(windows::core::Error::from_hresult(windows::core::HRESULT(hr)))
                } else { assert!(!raw.is_null()); Ok(ID3D12PipelineState::from_raw(raw)) };
                std::mem::ManuallyDrop::drop(&mut desc.pRootSignature);
                result
            };
            let first = make(None).unwrap();
            assert!(!super::super::is_adopted(first.as_raw()), "fixture must exercise the internal native compute pass path");
            let dir = test_dir();
            let p = dir.join("driver.pso");
            super::super::keep_compute_driver_blob(first.as_raw(), &p, std::time::Duration::from_secs(1));
            assert!(load(&p).is_some(), "native internal compute passes must persist driver blobs before adoption");
            super::super::adopt(first.as_raw(), super::super::Kind::PipelineState);
            super::super::keep_compute_driver_blob(first.as_raw(), &p, std::time::Duration::from_secs(1));
            assert!(load(&p).is_some(), "the adopted PSO must expose its native driver blob");
            let (warm, reused) = build(Some(&p), make).unwrap();
            assert!(reused, "the native driver must accept its own blob after disk roundtrip");
            assert!(!warm.as_raw().is_null());
            std::fs::remove_dir_all(dir).unwrap();
        }
    }
}
