// Modified for the CGBJ fork on 2026-11-25: project branding and/or documentation. Original XCL and third-party notices remain applicable.
//! Experimental asynchronous queue waits for real, monotonic CPU-visible counters.
//! Never release on a timeout or an unreadable address. No title work is moved to a worker.
use std::ffi::c_void;
use std::sync::{mpsc, OnceLock};
use std::time::{Duration, Instant};
use windows::core::Interface;
use windows::Win32::Graphics::Direct3D12::*;
use super::{list_x::PendingWait, real};

struct Gate { fence: ID3D12Fence, retired: ID3D12Fence, opened: bool, waits: Vec<PendingWait>, since: Instant, warned: bool, queue: usize }
// Only a free-threaded private fence and immutable predicate descriptions cross threads.
unsafe impl Send for Gate {}

fn worker() -> Option<&'static mpsc::SyncSender<Gate>> {
    static WORKER: OnceLock<Option<mpsc::SyncSender<Gate>>> = OnceLock::new();
    WORKER.get_or_init(|| {
        let (tx, rx) = mpsc::sync_channel::<Gate>(256);
        std::thread::Builder::new().name("cgbj-memory-gates".into()).spawn(move || unsafe {
            let mut pending: Vec<Gate> = Vec::new();
            loop {
                let incoming = if pending.len() >= 256 {
                    std::thread::sleep(Duration::from_millis(1)); None
                } else if pending.is_empty() {
                    match rx.recv() { Ok(g) => Some(g), Err(_) => break }
                } else {
                    match rx.recv_timeout(Duration::from_millis(1)) {
                        Ok(g) => Some(g), Err(mpsc::RecvTimeoutError::Timeout) => None,
                        Err(mpsc::RecvTimeoutError::Disconnected) => break,
                    }
                };
                if let Some(g) = incoming { pending.push(g); }
                pending.retain_mut(|g| {
                    // Retain both fences until the queue has actually passed its Wait.
                    // A CPU Signal alone does not prove the queued wait has consumed it.
                    if g.retired.GetCompletedValue() >= 1 || g.fence.GetCompletedValue() == u64::MAX { return false; }
                    if !g.opened && g.waits.iter().all(|w| w.gate_satisfied()) {
                        match g.fence.Signal(1) {
                            Ok(()) => { g.opened = true; crate::xlog_info!("memory-gate released: queue={:#x} age_ms={} waits={:x?}; real predicates observed", g.queue, g.since.elapsed().as_millis(), g.waits); }
                            Err(e) => { if !g.warned { crate::xlog_error!("memory-gate Signal failed: {e}"); g.warned = true; } }
                        }
                    }
                    if !g.warned && g.since.elapsed() >= Duration::from_secs(10) {
                        crate::xlog_warn!("memory-gate pending: queue={:#x} waits={:x?}; not released on timeout", g.queue, g.waits);
                        g.warned = true;
                    }
                    true
                });
            }
        }).ok().map(|_| tx)
    }).as_ref()
}

/// Queue a native wait without blocking the submitting CPU thread. False leaves legacy handling.
pub(super) unsafe fn enqueue(queue: *mut c_void, waits: &[PendingWait]) -> bool {
    if queue.is_null() || waits.is_empty() || waits.len() > 64 || !waits.iter().all(|w| w.gate_compatible()) { return false; }
    let Some(tx) = worker() else { return false };
    let Some(q) = ID3D12CommandQueue::from_raw_borrowed(&queue) else { return false };
    let mut dev: Option<ID3D12Device> = None;
    if q.GetDevice(&mut dev).is_err() { return false; }
    let Some(dev) = dev else { return false };
    let Ok(fence) = dev.CreateFence::<ID3D12Fence>(0, D3D12_FENCE_FLAG_NONE) else { return false };
    let Ok(retired) = dev.CreateFence::<ID3D12Fence>(0, D3D12_FENCE_FLAG_NONE) else { return false };
    // Admit the observer before the GPU wait, so a worker/channel failure cannot strand it.
    if tx.try_send(Gate { fence: fence.clone(), retired: retired.clone(), opened: false, waits: waits.to_vec(), since: Instant::now(), warned: false, queue: queue as usize }).is_err() { return false; }
    let hr = if real::is_adopted(queue) {
        // Console vtables shift Signal/Wait: call original PC Wait slot15 explicitly.
        let wait: unsafe extern "system" fn(*mut c_void, *mut c_void, u64) -> i32 = std::mem::transmute(real::orig_fn(queue, 15));
        wait(queue, fence.as_raw(), 1)
    } else { q.Wait(&fence, 1).map_or_else(|e| e.code().0, |_| 0) };
    if hr < 0 {
        // No queued fence use exists; retire this unused observer without opening its gate.
        let _ = retired.Signal(1);
        crate::xlog_error!("memory-gate native Wait failed: {hr:#x}"); return false;
    }
    let retire_hr = if real::is_adopted(queue) {
        let signal: unsafe extern "system" fn(*mut c_void, *mut c_void, u64) -> i32 = std::mem::transmute(real::orig_fn(queue, 14));
        signal(queue, retired.as_raw(), 1)
    } else { q.Signal(&retired, 1).map_or_else(|e| e.code().0, |_| 0) };
    if retire_hr < 0 { crate::xlog_error!("memory-gate retirement Signal failed: {retire_hr:#x}; fence ownership retained"); }
    crate::xlog_info!("memory-gate queued: queue={queue:p} waits={waits:x?}; CPU submission may continue");
    true
}
