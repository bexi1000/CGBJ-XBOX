// Modified for the CGBJ fork on 2026-11-25: project branding and/or documentation. Original XCL and third-party notices remain applicable.
//! Opt-in single-command MS producer/consumer support. All validation precedes recording.
use std::collections::HashMap;
use std::mem::ManuallyDrop;
use std::sync::{Arc, Mutex, OnceLock};
use windows::core::Interface;
use windows::Win32::Graphics::Direct3D12::*;
use super::indirect_mesh::{Pipeline, Plan, OUTPUT_BYTES};

pub(crate) fn enabled() -> bool {
    static ON: OnceLock<bool> = OnceLock::new();
    *ON.get_or_init(|| std::env::var("CGBJ_TWO_PASS_INDIRECT").is_ok_and(|v| v == "1"))
}

struct DeviceState {
    preparation: Pipeline,
    dispatch: ID3D12CommandSignature,
    mesh: ID3D12CommandSignature,
}

unsafe fn device_state(dev: &ID3D12Device) -> Result<Arc<DeviceState>, String> {
    static CACHE: Mutex<Option<HashMap<usize, Arc<DeviceState>>>> = Mutex::new(None);
    let mut g = CACHE.lock().unwrap();
    let cache = g.get_or_insert_with(HashMap::new);
    let key = dev.as_raw() as usize;
    if let Some(s) = cache.get(&key) { return Ok(Arc::clone(s)); }
    let signature = |ty| -> Result<ID3D12CommandSignature, String> {
        let arg = D3D12_INDIRECT_ARGUMENT_DESC { Type: ty, ..Default::default() };
        let desc = D3D12_COMMAND_SIGNATURE_DESC { ByteStride: 12, NumArgumentDescs: 1, pArgumentDescs: &arg, NodeMask: 0 };
        let mut sig: Option<ID3D12CommandSignature> = None;
        dev.CreateCommandSignature(&desc, None, &mut sig).map_err(|e| e.to_string())?;
        sig.ok_or("no native indirect signature".into())
    };
    let state = Arc::new(DeviceState { preparation: Pipeline::new(dev)?,
        dispatch: signature(D3D12_INDIRECT_ARGUMENT_TYPE_DISPATCH)?, mesh: signature(D3D12_INDIRECT_ARGUMENT_TYPE_DISPATCH_MESH)? });
    cache.insert(key, Arc::clone(&state));
    Ok(state)
}

pub(crate) struct Prepared {
    pub control: ID3D12Resource,
    pub readback: ID3D12Resource,
    pub dispatch: ID3D12CommandSignature,
    pub mesh: ID3D12CommandSignature,
    inputs: Vec<ID3D12Resource>,
    _owner: Arc<DeviceState>,
}

impl Prepared {
    pub(super) fn inspection(self, records: ID3D12Resource, pipelines: Vec<ID3D12PipelineState>, callback: fn(&[u32])) -> super::cpu_writes::ReadbackInspection {
        let mut resources = self.inputs;
        resources.extend([self.control, records]);
        super::cpu_writes::ReadbackInspection { readback: self.readback, dwords: (OUTPUT_BYTES / 4) as u32,
            callback, _resources: resources, _pipelines: pipelines }
        // DeviceState (preparation PSO/root and private signatures) remains in CACHE.
    }
}

unsafe fn buffer(dev: &ID3D12Device, readback: bool) -> Result<ID3D12Resource, String> {
    let desc = D3D12_RESOURCE_DESC { Dimension: D3D12_RESOURCE_DIMENSION_BUFFER, Width: 64, Height: 1,
        DepthOrArraySize: 1, MipLevels: 1, SampleDesc: windows::Win32::Graphics::Dxgi::Common::DXGI_SAMPLE_DESC { Count: 1, Quality: 0 },
        Layout: D3D12_TEXTURE_LAYOUT_ROW_MAJOR,
        Flags: if readback { D3D12_RESOURCE_FLAG_NONE } else { D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS }, ..Default::default() };
    let mut out: Option<ID3D12Resource> = None;
    dev.CreateCommittedResource(&D3D12_HEAP_PROPERTIES { Type: if readback { D3D12_HEAP_TYPE_READBACK } else { D3D12_HEAP_TYPE_DEFAULT }, ..Default::default() },
        D3D12_HEAP_FLAG_NONE, &desc, if readback { D3D12_RESOURCE_STATE_COPY_DEST } else { D3D12_RESOURCE_STATE_UNORDERED_ACCESS }, None, &mut out).map_err(|e| e.to_string())?;
    out.ok_or("no indirect control/readback buffer".into())
}

unsafe fn transition(list: &ID3D12GraphicsCommandList, r: &ID3D12Resource, before: D3D12_RESOURCE_STATES, after: D3D12_RESOURCE_STATES) {
    let mut b = D3D12_RESOURCE_BARRIER { Type: D3D12_RESOURCE_BARRIER_TYPE_TRANSITION,
        Anonymous: D3D12_RESOURCE_BARRIER_0 { Transition: ManuallyDrop::new(D3D12_RESOURCE_TRANSITION_BARRIER {
            pResource: ManuallyDrop::new(Some(r.clone())), Subresource: D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, StateBefore: before, StateAfter: after }) }, ..Default::default() };
    list.ResourceBarrier(&[std::ptr::read(&b)]);
    ManuallyDrop::drop(&mut (*b.Anonymous.Transition).pResource);
}

/// Non-upload inputs follow ExecuteIndirect's INDIRECT_ARGUMENT state contract. Upload heaps
/// must stay GENERIC_READ, which already permits the preparation shader's read.
#[allow(clippy::too_many_arguments)]
pub(crate) unsafe fn prepare(dev: &ID3D12Device, list: &ID3D12GraphicsCommandList, args: &ID3D12Resource,
    args_offset: u64, counts: Option<(&ID3D12Resource, u64)>, record_dwords: u64, record_bytes: u64, split: u32, maximum: u32,
) -> Result<Prepared, String> {
    let plan = Plan::new(record_dwords, record_bytes, split, maximum)?;
    let control = buffer(dev, false)?;
    let readback = buffer(dev, true)?;
    Pipeline::validate_buffers(args, args_offset, counts, &control)?;
    let mut inputs = vec![args.clone()];
    if let Some((r, _)) = counts { if r.as_raw() != args.as_raw() { inputs.push(r.clone()); } }
    let mut transitions = Vec::new();
    for r in &inputs {
        let mut props = D3D12_HEAP_PROPERTIES::default();
        if !super::real::is_reserved(r.as_raw()) {
            r.GetHeapProperties(Some(&mut props), None).map_err(|e| e.to_string())?;
            if props.Type == D3D12_HEAP_TYPE_READBACK { return Err("indirect input is a readback heap".into()); }
        }
        if props.Type != D3D12_HEAP_TYPE_UPLOAD { transitions.push(r); }
    }
    let owner = device_state(dev)?;
    for r in &transitions { transition(list, r, D3D12_RESOURCE_STATE_INDIRECT_ARGUMENT, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE); }
    let result = owner.preparation.record(list, plan, args, args_offset, counts, &control);
    for r in &transitions { transition(list, r, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_INDIRECT_ARGUMENT); }
    result?;
    transition(list, &control, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_INDIRECT_ARGUMENT | D3D12_RESOURCE_STATE_COPY_SOURCE);
    list.CopyBufferRegion(&readback, 0, &control, 0, OUTPUT_BYTES);
    Ok(Prepared { control, readback, dispatch: owner.dispatch.clone(), mesh: owner.mesh.clone(), inputs, _owner: owner })
}
