//! Owned metadata for indirect signatures; no title command execution policy here.
use std::collections::HashMap;
use std::sync::{Mutex, atomic::{AtomicU64, Ordering}};
use windows::Win32::Graphics::Direct3D12::*;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct Metadata {
    pub generation: u64,
    pub mesh_stride: Option<u32>,
}

static SIGNATURES: Mutex<Option<HashMap<usize, Metadata>>> = Mutex::new(None);

fn mesh_stride(stride: u32, types: &[D3D12_INDIRECT_ARGUMENT_TYPE]) -> Option<u32> {
    (types == [D3D12_INDIRECT_ARGUMENT_TYPE_DISPATCH_MESH] && stride >= 12 && stride % 4 == 0).then_some(stride)
}

/// Called only after successful native creation, while its descriptor still lives.
pub(super) unsafe fn created(signature: usize, desc: &D3D12_COMMAND_SIGNATURE_DESC) {
    static NEXT: AtomicU64 = AtomicU64::new(1);
    let stride = if desc.NumArgumentDescs == 1 && !desc.pArgumentDescs.is_null() {
        mesh_stride(desc.ByteStride, &[(*desc.pArgumentDescs).Type])
    } else { None };
    SIGNATURES.lock().unwrap().get_or_insert_with(HashMap::new).insert(signature,
        Metadata { generation: NEXT.fetch_add(1, Ordering::Relaxed), mesh_stride: stride });
}

pub(super) fn get(signature: usize) -> Option<Metadata> {
    SIGNATURES.lock().unwrap().as_ref()?.get(&signature).copied()
}

pub(super) fn released(signature: usize, generation: Option<u64>) {
    let mut g = SIGNATURES.lock().unwrap();
    if let Some(m) = g.as_mut() {
        if m.get(&signature).is_some_and(|v| Some(v.generation) == generation) { m.remove(&signature); }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use windows::core::Interface;

    #[test]
    fn mesh_layout_rejects_other_and_root_changing_commands_and_old_release_keeps_reused_address() {
        assert_eq!(mesh_stride(16, &[D3D12_INDIRECT_ARGUMENT_TYPE_DISPATCH_MESH]), Some(16));
        for stride in [0, 8, 13] { assert_eq!(mesh_stride(stride, &[D3D12_INDIRECT_ARGUMENT_TYPE_DISPATCH_MESH]), None); }
        assert_eq!(mesh_stride(12, &[D3D12_INDIRECT_ARGUMENT_TYPE_DISPATCH]), None);
        assert_eq!(mesh_stride(16, &[D3D12_INDIRECT_ARGUMENT_TYPE_CONSTANT, D3D12_INDIRECT_ARGUMENT_TYPE_DISPATCH_MESH]), None);
        let arg = D3D12_INDIRECT_ARGUMENT_DESC { Type: D3D12_INDIRECT_ARGUMENT_TYPE_DISPATCH_MESH, ..Default::default() };
        let desc = D3D12_COMMAND_SIGNATURE_DESC { ByteStride: 12, NumArgumentDescs: 1, pArgumentDescs: &arg, NodeMask: 0 };
        let signature = 0x7734_0001;
        unsafe { created(signature, &desc); }
        let old = get(signature).unwrap().generation;
        unsafe { created(signature, &D3D12_COMMAND_SIGNATURE_DESC::default()); }
        let new = get(signature).unwrap();
        released(signature, Some(old));
        assert_eq!(get(signature), Some(new), "old final Release must not remove a reused object's metadata");
        assert_eq!(new.mesh_stride, None, "new unsupported signature must not inherit an old mesh layout");
        released(signature, Some(new.generation));
        assert_eq!(get(signature), None);
    }

    #[test]
    fn native_signature_metadata_survives_addref_and_leaves_on_final_release() {
        unsafe {
            let Ok(dev) = crate::gpu::agility::create_device(None, windows::Win32::Graphics::Direct3D::D3D_FEATURE_LEVEL_11_0) else {
                return crate::gpu::recomp::runner::skip_test("no D3D12 GPU");
            };
            super::super::real::adopt(dev.as_raw(), super::super::real::Kind::Device);
            let arg = D3D12_INDIRECT_ARGUMENT_DESC { Type: D3D12_INDIRECT_ARGUMENT_TYPE_DISPATCH, ..Default::default() };
            let desc = D3D12_COMMAND_SIGNATURE_DESC { ByteStride: 12, NumArgumentDescs: 1, pArgumentDescs: &arg, NodeMask: 0 };
            let mut sig: Option<ID3D12CommandSignature> = None;
            dev.CreateCommandSignature(&desc, None, &mut sig).unwrap();
            let sig = sig.unwrap();
            let key = sig.as_raw() as usize;
            let copy = sig.clone();
            assert!(get(key).is_some());
            drop(sig);
            assert!(get(key).is_some());
            drop(copy);
            assert_eq!(get(key), None);
        }
    }
}
