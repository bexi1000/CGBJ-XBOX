//! Bounded identity/timing evidence. Never changes compilation or queue order.
use std::{cell::Cell, sync::{Mutex, atomic::{AtomicU64, Ordering}}, time::Instant};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct Context { pub build: usize, pub shader: u64, pub role: &'static str, pub compute: bool }
thread_local! { static CONTEXT: Cell<Option<Context>> = const { Cell::new(None) }; }
pub(crate) fn current() -> Option<Context> { CONTEXT.with(Cell::get) }
pub(crate) struct Installed(Option<Context>);
pub(crate) fn install(c: Option<Context>) -> Installed { Installed(CONTEXT.with(|v| v.replace(c))) }
impl Drop for Installed { fn drop(&mut self) { CONTEXT.with(|v| v.set(self.0)); } }
pub(crate) fn enabled() -> bool { super::critical_path::enabled() }
pub(crate) fn event(kind: &str, detail: std::fmt::Arguments<'_>) {
    if !enabled() { return; }
    static N: AtomicU64 = AtomicU64::new(0);
    let n = N.fetch_add(1, Ordering::Relaxed);
    if n < 32768 { crate::xlog_info!("pipeline-audit {kind}: context={:x?} {detail}", current()); }
    else if n == 32768 { crate::xlog_warn!("pipeline-audit event quota exhausted; later absence is unknown"); }
}
struct Active { id: u64, phase: &'static str, context: Option<Context>, tid: u32, key: String, start: Instant }
static ACTIVE: Mutex<Vec<Active>> = Mutex::new(Vec::new());
pub(crate) struct Span { id: u64, phase: &'static str, key: String, start: Instant }
pub(crate) fn span(phase: &'static str, key: impl FnOnce() -> String) -> Option<Span> {
    if !enabled() { return None; }
    static NEXT: AtomicU64 = AtomicU64::new(1);
    let (id, key, start) = (NEXT.fetch_add(1, Ordering::Relaxed), key(), Instant::now());
    let mut rows = ACTIVE.lock().unwrap();
    if rows.len() >= 256 { return None; }
    rows.push(Active { id, phase, context: current(), tid: unsafe { windows_sys::Win32::System::Threading::GetCurrentThreadId() }, key: key.clone(), start });
    drop(rows);
    event("begin", format_args!("span={id} phase={phase} key={key}"));
    Some(Span { id, phase, key, start })
}
impl Drop for Span {
    fn drop(&mut self) {
        ACTIVE.lock().unwrap().retain(|a| a.id != self.id);
        event("end", format_args!("span={} phase={} key={} elapsed_us={}", self.id, self.phase, self.key, self.start.elapsed().as_micros()));
    }
}
pub(super) fn sample() {
    let Ok(rows) = ACTIVE.try_lock() else { return };
    let snapshot: Vec<_> = rows.iter().take(32).map(|a| (a.id,a.phase,a.context,a.tid,a.key.clone(),a.start.elapsed().as_millis())).collect();
    drop(rows);
    crate::xlog_info!("pipeline-audit active: (span,phase,context,tid,key,age_ms)={snapshot:x?}");
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn nested_and_worker_context_restore_on_unwind() {
        assert_eq!(current(), None);
        let a = Context { build: 1, shader: 2, role: "preload", compute: true };
        let b = Context { build: 3, shader: 4, role: "caller", compute: false };
        let outer = install(Some(a));
        let worker = std::thread::spawn(move || { assert_eq!(current(), None); let _scope=install(Some(a)); current() }).join().unwrap();
        assert_eq!(worker, Some(a));
        let _ = std::panic::catch_unwind(|| { let _scope=install(Some(b)); assert_eq!(current(), Some(b)); panic!("audit context fixture"); });
        assert_eq!(current(), Some(a)); drop(outer); assert_eq!(current(), None);
    }
}
