// Modified for the CGBJ fork on 2026-11-25: project branding and/or documentation. Original XCL and third-party notices remain applicable.
//! Non-blocking pipeline creation. Translating a console shader takes milliseconds; compiling
//! the HLSL with DXC takes 0.2 s to seconds, and a title creates thousands of pipelines while
//! it loads. When a pipeline's DXIL is not in the disk cache yet, the title gets a stand-in
//! pipeline (shaders that draw nothing) at once and the real one is built on a worker; binding
//! (`SetPipelineState`, console list replay, the two-pass lookups) uses the real one as soon
//! as it is there. A graphics pipeline draws nothing until then; a compute pipeline is waited
//! for at its first bind (a skipped dispatch would corrupt what it computes).
//! `CGBJ_ASYNC_PSO=0` builds every pipeline in the call, as before.

use std::collections::HashMap;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{mpsc, Arc, Condvar, Mutex, OnceLock};

struct Pending {
    /// the build, until a worker – or a bind that cannot wait for the queue – takes it
    job: Mutex<Option<Job>>,
    /// the build went to the workers (a lazy one goes on its first `resolve`)
    sent: std::sync::atomic::AtomicBool,
    /// the real pipeline state (raw pointer), 0 while building or when building failed
    real: AtomicUsize,
    done: Mutex<bool>,
    cv: Condvar,
    compute: bool,
    /// of its shaders (`used`); 0 = none
    key: u64,
    /// it was used (`used::note` is told once)
    used: std::sync::atomic::AtomicBool,
    bound: std::sync::atomic::AtomicBool,
    /// the stand-in was released before the real pipeline was built
    orphan: std::sync::atomic::AtomicBool,
}

impl Pending {
    fn audit_context(&self, role: &'static str) -> super::pipeline_audit::Installed {
        super::pipeline_audit::install(Some(super::pipeline_audit::Context { build: self as *const Self as usize, shader: self.key, role, compute: self.compute }))
    }
    fn note_use(&self) {
        if self.key != 0 && !self.used.swap(true, Ordering::Relaxed) {
            used::note(self.key);
        }
    }
}

/// stand-in handed to the title → its real pipeline
static PENDING: Mutex<Option<HashMap<usize, Arc<Pending>>>> = Mutex::new(None);

/// The build is done (`real`: its pipeline, 0 = failed).
fn complete(p: &Pending, real: usize) {
    if real == 0 {
        FAILED.fetch_add(1, Ordering::Relaxed);
    } else {
        BUILT.fetch_add(1, Ordering::Relaxed);
    }
    let orphan = {
        let mut done = p.done.lock().unwrap();
        let orphan = p.orphan.load(Ordering::Acquire);
        if !orphan {
            p.real.store(real, Ordering::Release);
        }
        *done = true;
        p.cv.notify_all();
        orphan
    };
    // outside `done`: the Release override takes PENDING (`counts` takes PENDING, then `done`)
    if orphan {
        release(real);
    }
}
static BUILT: AtomicUsize = AtomicUsize::new(0);
static FAILED: AtomicUsize = AtomicUsize::new(0);

/// Opt-in, bounded spans for diagnosing build/wait ordering. No wait or scheduling policy
/// changes; a span left open at a crash identifies the outstanding worker or caller.
struct TraceSpan {
    key: usize,
    phase: &'static str,
    started: std::time::Instant,
}

impl TraceSpan {
    fn begin(p: &Pending, phase: &'static str, caller_builds: bool) -> Option<Self> {
        static ON: OnceLock<bool> = OnceLock::new();
        static N: AtomicUsize = AtomicUsize::new(0);
        if !*ON.get_or_init(|| std::env::var("CGBJ_TRACE_PSO_ORDER").is_ok_and(|v| v == "1")) {
            return None;
        }
        static AFTER: OnceLock<f64> = OnceLock::new();
        let after = *AFTER.get_or_init(|| std::env::var("CGBJ_TRACE_PSO_ORDER_AFTER")
            .ok().and_then(|v| v.parse::<f64>().ok()).filter(|v| v.is_finite() && *v >= 0.0).unwrap_or(0.0));
        if crate::log::uptime() < after {
            return None;
        }
        if *p.done.lock().unwrap() || N.fetch_add(1, Ordering::Relaxed) >= 128 {
            return None;
        }
        let key = p as *const Pending as usize;
        let kind = if p.compute { "compute" } else { "graphics" };
        crate::xlog_info!("PSO order: begin {phase} key={key:#x} kind={kind} caller-builds={caller_builds}");
        Some(Self { key, phase, started: std::time::Instant::now() })
    }
}

impl Drop for TraceSpan {
    fn drop(&mut self) {
        crate::xlog_info!("PSO order: end {} key={:#x} elapsed={} ms", self.phase, self.key, self.started.elapsed().as_millis());
    }
}

pub fn enabled() -> bool {
    std::env::var("CGBJ_ASYNC_PSO").map_or(true, |v| v != "0")
}

pub(super) fn diagnostic(pso: usize) -> String {
    let p = {
        let Ok(g) = PENDING.try_lock() else { return "pending_map=busy".into() };
        let Some(p) = g.as_ref().and_then(|m| m.get(&pso)).cloned() else { return "pending=unknown".into() };
        p
    };
    format!("build_key={:#x} shader_key={:#x} compute={} done={:?} sent={} job_available={:?} real={:#x}",
        &*p as *const Pending as usize, p.key, p.compute, p.done.try_lock().ok().map(|v| *v),
        p.sent.load(Ordering::Acquire), p.job.try_lock().ok().map(|v| v.is_some()), p.real.load(Ordering::Acquire))
}

/// Builds the real pipeline: its raw pointer, 0 = failed.
pub type Job = Box<dyn FnOnce() -> usize + Send>;

fn queue() -> &'static Mutex<mpsc::Sender<Arc<Pending>>> {
    static Q: OnceLock<Mutex<mpsc::Sender<Arc<Pending>>>> = OnceLock::new();
    Q.get_or_init(|| {
        let (tx, rx) = mpsc::channel::<Arc<Pending>>();
        let rx = Arc::new(Mutex::new(rx));
        // translation recurses deeply on big programs; DXC itself runs on its own pool
        let n = crate::gpu::recomp::dxc::compile_threads();
        for k in 0..n {
            let rx = rx.clone();
            let _ = std::thread::Builder::new().name(format!("cgbj-pso-{k}")).stack_size(64 << 20).spawn(move || loop {
                let next = rx.lock().unwrap().recv();
                let Ok(p) = next else { return };
                // (None: a bind took it and builds it itself)
                let job = p.job.lock().unwrap().take();
                if let Some(job) = job {
                    let _context = p.audit_context("worker");
                    let _audit = super::pipeline_audit::span("build", || format!("{:x}", p.key));
                    let _trace = TraceSpan::begin(&p, "worker", true);
                    let _perf = super::perf::scope("build", p.compute, &*p as *const Pending as usize, false);
                    complete(&p, job());
                }
            });
        }
        Mutex::new(tx)
    })
}

/// Release a pipeline state CGBJ owns (raw pointer, 0 = none).
pub fn release(p: usize) {
    if p != 0 {
        unsafe { drop(<windows::Win32::Graphics::Direct3D12::ID3D12PipelineState as windows::core::Interface>::from_raw(p as *mut std::ffi::c_void)) };
    }
}

/// `standin` went to the title; `job` builds the real pipeline on a worker.
pub fn submit(standin: usize, compute: bool, job: Job) {
    submit_as(standin, compute, job, true, 0);
}

/// Lazy pipeline creation (`CGBJ_LAZY_PSO=0`: off): a title's pipelines with console shaders get
/// their stand-in when made and are built when first used – the first bind of a graphics one
/// sends it to the workers, a compute one is built at its first bind. A retail game makes
/// ~51 000 pipelines in its first 30 s and uses few; each one built stays in the driver
/// (~400 KB), and the process ran out of commit.
pub fn lazy() -> bool {
    static L: OnceLock<bool> = OnceLock::new();
    *L.get_or_init(|| enabled() && std::env::var("CGBJ_LAZY_PSO").map_or(true, |v| v != "0"))
}

/// `submit`, sent to the workers only on its first `resolve` (`lazy`) – or now, at a low
/// priority, when an earlier run used a pipeline of these shaders (`key`, 0 = none; `used`).
pub fn submit_lazy(standin: usize, compute: bool, job: Job, key: u64) {
    submit_as(standin, compute, job, false, key);
}

/// Limit optional speculative work for a controlled critical-path comparison. Actual binds
/// still build every required pipeline through resolve/resolve_wait.
fn parse_preload_keys(text: &str) -> Result<std::collections::HashSet<u64>, &'static str> {
    if text.len() > 1088 { return Err("preload key list too long"); }
    let mut keys = std::collections::HashSet::new();
    for part in text.split(',') {
        let s = part.trim().strip_prefix("0x").unwrap_or(part.trim());
        let key = u64::from_str_radix(s, 16).map_err(|_| "invalid preload key")?;
        if key == 0 || s.len() > 16 { return Err("invalid preload key"); }
        keys.insert(key);
        if keys.len() > 64 { return Err("too many preload keys"); }
    }
    Ok(keys)
}

fn preload_keys() -> Option<&'static std::collections::HashSet<u64>> {
    static KEYS: OnceLock<Option<std::collections::HashSet<u64>>> = OnceLock::new();
    KEYS.get_or_init(|| match std::env::var("CGBJ_PSO_PRELOAD_KEYS") {
        Ok(s) => match parse_preload_keys(&s) {
            Ok(keys) => { crate::xlog_info!("PSO preload focus: {} keys; other pipelines still build when used", keys.len()); Some(keys) }
            Err(e) => { crate::xlog_warn!("PSO preload focus ignored: {e}"); None }
        },
        Err(_) => None,
    }).as_ref()
}

fn preload_matches(key: u64, filter: Option<&std::collections::HashSet<u64>>) -> bool {
    filter.is_none_or(|keys| keys.contains(&key))
}

fn submit_as(standin: usize, compute: bool, job: Job, send: bool, key: u64) {
    let p = Arc::new(Pending {
        job: Mutex::new(Some(job)),
        sent: std::sync::atomic::AtomicBool::new(send),
        real: AtomicUsize::new(0),
        done: Mutex::new(false),
        cv: Condvar::new(),
        compute,
        key,
        used: Default::default(),
        bound: Default::default(),
        orphan: Default::default(),
    });
    PENDING.lock().unwrap().get_or_insert_with(HashMap::new).insert(standin, p.clone());
    static ONCE: std::sync::Once = std::sync::Once::new();
    ONCE.call_once(|| {
        crate::xlog_info!("D3D12.X: pipelines whose shaders are not compiled yet get a stand-in and are built in the background");
    });
    if send {
        let _ = queue().lock().unwrap().send(p);
    } else if used::known(key) && preload_matches(key, preload_keys()) {
        if let Some(q) = preload() {
            q.list.lock().unwrap().push_back(p);
            q.cv.notify_one();
        }
    }
}

/// The pipelines a title used, by a hash of their shaders, kept between runs
/// (`used-pipelines.txt` beside the DXIL cache, a key a line).
///
/// A lazy pipeline is built at its first use: until then a graphics one draws nothing, and a
/// compute one is waited for on the title's thread. A retail title's first frames of its world
/// use hundreds of pipelines for the first time at once. The pipelines of an earlier run are
/// built while the title loads instead (`preload`): measured on a build that skips a dispatch
/// instead of waiting for its pipeline, ~2 170 dispatches were skipped in those frames without
/// this and 94 – 150 with it.
mod used {
    use std::collections::HashSet;
    use std::io::Write;
    use std::sync::{Mutex, OnceLock, RwLock};

    struct Used {
        earlier: RwLock<HashSet<u64>>,
        now: Mutex<(HashSet<u64>, Option<std::fs::File>)>,
    }

    /// The keys in a `used-pipelines.txt` (lines that are not a hexadecimal key are passed over).
    pub fn parse(text: &str) -> HashSet<u64> {
        text.lines().filter_map(|l| u64::from_str_radix(l.trim(), 16).ok()).filter(|&k| k != 0).collect()
    }

    fn get() -> &'static Used {
        static U: OnceLock<Used> = OnceLock::new();
        U.get_or_init(|| {
            // (a test neither reads nor writes the user's file)
            if cfg!(test) {
                return Used { earlier: RwLock::new(HashSet::new()), now: Mutex::new((HashSet::new(), None)) };
            }
            let path = crate::gpu::recomp::dxc::cache_dir().join("used-pipelines.txt");
            let earlier = parse(&std::fs::read_to_string(&path).unwrap_or_default());
            if !earlier.is_empty() {
                crate::xlog_info!("D3D12.X: the pipelines of {} shader sets an earlier run used are built ahead of their first use", earlier.len());
            }
            if let Some(dir) = path.parent() {
                let _ = std::fs::create_dir_all(dir);
            }
            let file = std::fs::OpenOptions::new().create(true).append(true).open(&path).ok();
            Used { now: Mutex::new((earlier.clone(), file)), earlier: RwLock::new(earlier) }
        })
    }

    /// An earlier run used a pipeline of these shaders.
    pub fn known(key: u64) -> bool {
        key != 0 && get().earlier.read().unwrap().contains(&key)
    }

    /// A pipeline of these shaders is used now: kept for the next run.
    pub fn note(key: u64) {
        if key == 0 {
            return;
        }
        let mut g = get().now.lock().unwrap();
        if g.0.insert(key) {
            if let Some(f) = g.1.as_mut() {
                let _ = writeln!(f, "{key:016x}");
            }
        }
    }

    /// (tests) This run used a pipeline of these shaders.
    #[cfg(test)]
    pub fn noted(key: u64) -> bool {
        get().now.lock().unwrap().0.contains(&key)
    }

    #[cfg(test)]
    pub fn earlier_run_used(key: u64) {
        get().earlier.write().unwrap().insert(key);
    }
}

/// The workers that build the pipelines of an earlier run ahead of their first use
/// (`CGBJ_PSO_PRELOAD=0`: off). Apart from the ones a bind sends to (`queue`) and at the lowest
/// priority: a pipeline that is bound is not held up by the ones made ahead (whoever takes
/// `job` first builds it), and the title's own threads are not either.
struct Preload {
    list: Mutex<std::collections::VecDeque<Arc<Pending>>>,
    cv: Condvar,
}

fn preload() -> Option<&'static Preload> {
    static Q: OnceLock<Option<Preload>> = OnceLock::new();
    static STARTED: std::sync::Once = std::sync::Once::new();
    let q = Q
        .get_or_init(|| {
            if std::env::var("CGBJ_PSO_PRELOAD").is_ok_and(|v| v.trim() == "0") {
                return None;
            }
            Some(Preload { list: Mutex::new(Default::default()), cv: Condvar::new() })
        })
        .as_ref()?;
    STARTED.call_once(|| {
        let n = (crate::gpu::recomp::dxc::compile_threads() / 4).clamp(2, 4);
        for k in 0..n {
            let _ = std::thread::Builder::new().name(format!("cgbj-pso-pre-{k}")).stack_size(64 << 20).spawn(move || {
                unsafe {
                    use windows_sys::Win32::System::Threading::{GetCurrentThread, SetThreadPriority, THREAD_PRIORITY_LOWEST};
                    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_LOWEST);
                }
                static DONE: AtomicUsize = AtomicUsize::new(0);
                loop {
                    let p = {
                        let mut g = q.list.lock().unwrap();
                        loop {
                            if let Some(p) = g.pop_front() {
                                break p;
                            }
                            g = q.cv.wait(g).unwrap();
                        }
                    };
                    // (released by the title meanwhile)
                    if p.orphan.load(Ordering::Acquire) {
                        continue;
                    }
                    // (None: a bind took it and builds it itself)
                    let job = p.job.lock().unwrap().take();
                    if let Some(job) = job {
                        let _context = p.audit_context("preload");
                        let _audit = super::pipeline_audit::span("build", || format!("{:x}", p.key));
                        let focused = preload_keys().is_some();
                        if focused { crate::xlog_info!("PSO preload focus begin: shader_key={:#x} build_key={:#x}", p.key, &*p as *const Pending as usize); }
                        let _trace = TraceSpan::begin(&p, "preload", true);
                        let _perf = super::perf::scope("build", p.compute, &*p as *const Pending as usize, false);
                        let real = job();
                        if focused { crate::xlog_info!("PSO preload focus end: shader_key={:#x} build_key={:#x} success={}", p.key, &*p as *const Pending as usize, real != 0); }
                        complete(&p, real);
                        let n = DONE.fetch_add(1, Ordering::Relaxed) + 1;
                        if n.is_power_of_two() {
                            crate::xlog_info!("D3D12.X: {n} pipelines built ahead of their first use");
                        }
                    }
                }
            });
        }
    });
    Some(q)
}

#[cfg(test)]
mod used_tests {
    use super::*;

    #[test]
    fn preload_focus_is_bounded_exact_and_does_not_change_default() {
        let keys = parse_preload_keys("0x12, abcd,12").unwrap();
        assert_eq!(keys.len(), 2);
        assert!(preload_matches(0x12, Some(&keys)));
        assert!(!preload_matches(0x13, Some(&keys)));
        assert!(preload_matches(0x13, None));
        for bad in ["", "0", "12,", "xyz", "10000000000000000"] { assert!(parse_preload_keys(bad).is_err()); }
        let many = (1..=65).map(|k| format!("{k:x}")).collect::<Vec<_>>().join(",");
        assert!(parse_preload_keys(&many).is_err());
    }

    #[test]
    fn the_keys_of_a_file_are_read_and_other_lines_passed_over() {
        let keys = used::parse("00000000000000ff\n\nnot a key\n  1a2b \n0\n");
        assert_eq!(keys.len(), 2);
        assert!(keys.contains(&0xff) && keys.contains(&0x1a2b));
    }

    /// A lazy pipeline of shaders an earlier run used is built without a bind; another one is
    /// built only at its first use, and that use is kept for the next run.
    #[test]
    fn a_pipeline_an_earlier_run_used_is_built_ahead_of_its_first_use() {
        let (known, unknown) = (0x7E57_7001usize, 0x7E57_7002usize);
        let (known_key, unknown_key) = (0x5EED_0001u64, 0x5EED_0002u64);
        used::earlier_run_used(known_key);
        submit_lazy(known, false, Box::new(|| 0x4321), known_key);
        submit_lazy(unknown, false, Box::new(|| 0x4322), unknown_key);
        let start = std::time::Instant::now();
        while is_pending(known) && start.elapsed() < std::time::Duration::from_secs(10) {
            std::thread::sleep(std::time::Duration::from_millis(5));
        }
        assert!(!is_pending(known), "built by the workers that build ahead, with no bind");
        assert_eq!(resolve(known), 0x4321);
        assert!(is_pending(unknown), "nobody used it and no earlier run did");
        assert!(!used::noted(unknown_key));
        assert_eq!(resolve_wait(unknown), 0x4322);
        assert!(used::noted(unknown_key) && used::noted(known_key), "a first use is kept for the next run");
        released(known);
        released(unknown);
    }
}

fn entry(pso: usize) -> Option<Arc<Pending>> {
    PENDING.lock().unwrap().as_ref()?.get(&pso).cloned()
}

/// The pipeline to use for `pso` now: the real one once built, else `pso` itself.
pub fn resolve(pso: usize) -> usize {
    let Some(p) = entry(pso) else { return pso };
    p.note_use();
    match p.real.load(Ordering::Acquire) {
        0 => {
            // a lazy one is wanted now: to the workers
            if !p.sent.swap(true, Ordering::AcqRel) {
                let _ = queue().lock().unwrap().send(p);
            }
            pso
        }
        r => r,
    }
}

/// `resolve`, waiting for a pipeline still being built – built here if no worker has started
/// it yet (a queue of a title's hundreds of pipelines must not hold up the one it binds now).
pub fn resolve_wait(pso: usize) -> usize {
    let Some(p) = entry(pso) else { return pso };
    let _demand_context = p.audit_context("demand");
    let _demand_span = if super::pipeline_audit::enabled() && !*p.done.lock().unwrap() {
        super::pipeline_audit::span("wait", || format!("pso={pso:x}"))
    } else { None };
    p.note_use();
    let job = p.job.lock().unwrap().take();
    let _trace = TraceSpan::begin(&p, "wait", job.is_some());
    let _perf_wait = super::perf::scope("wait", p.compute, &*p as *const Pending as usize, job.is_some());
    if let Some(job) = job {
        let _context = p.audit_context("caller");
        let _audit = super::pipeline_audit::span("build", || format!("{:x}", p.key));
        let _perf_build = super::perf::scope("build", p.compute, &*p as *const Pending as usize, true);
        complete(&p, job());
    }
    let mut done = p.done.lock().unwrap();
    while !*done {
        done = p.cv.wait(done).unwrap();
    }
    match p.real.load(Ordering::Acquire) {
        0 => pso,
        r => r,
    }
}

/// For binding: compute pipelines are waited for, graphics ones are not.
pub fn resolve_for_bind(pso: usize) -> usize {
    match entry(pso) {
        Some(p) if p.compute => resolve_wait(pso),
        Some(_) => resolve(pso),
        None => pso,
    }
}

pub(super) fn audit_binding(list: usize, pso: usize) {
    if !super::pipeline_audit::enabled() { return; }
    if let Some(p) = entry(pso) {
        if !p.bound.swap(true, Ordering::Relaxed) {
            super::pipeline_audit::event("bound", format_args!("list={list:#x} pso={pso:#x} shader_key={:#x} build_key={:#x} compute={} real={:#x}; recording only, not GPU execution", p.key, &*p as *const Pending as usize, p.compute, p.real.load(Ordering::Acquire)));
        }
    }
}

pub(super) fn audit_dispatch(list: usize, pso: usize) {
    if !super::pipeline_audit::enabled() { return; }
    if let Some(p) = entry(pso) {
        super::critical_path::record(list, super::critical_path::Kind::ComputeUse { pso, shader: p.key, build: &*p as *const Pending as usize });
    }
}

/// The title released stand-in `pso` for good: forget it (its address may come back for
/// another object) and return its real pipeline to release (0: none, or still being built –
/// the worker's result is then released when it arrives).
pub fn released(pso: usize) -> usize {
    let Some(p) = PENDING.lock().unwrap().as_mut().and_then(|m| m.remove(&pso)) else { return 0 };
    let done = p.done.lock().unwrap();
    if *done {
        p.real.swap(0, Ordering::AcqRel)
    } else {
        // the worker stores its result into a Pending nobody will read: mark it orphaned
        p.orphan.store(true, Ordering::Release);
        0
    }
}

/// `pso` is a stand-in whose real pipeline is still being built.
pub fn is_pending(pso: usize) -> bool {
    entry(pso).is_some_and(|p| !*p.done.lock().unwrap())
}

/// (built in the background, failed, still building)
pub fn counts() -> (usize, usize, usize) {
    let pending = PENDING.lock().unwrap().as_ref().map_or(0, |m| m.values().filter(|p| !*p.done.lock().unwrap()).count());
    (BUILT.load(Ordering::Relaxed), FAILED.load(Ordering::Relaxed), pending)
}
