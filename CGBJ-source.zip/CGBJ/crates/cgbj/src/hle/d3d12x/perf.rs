// Modified for the CGBJ fork on 2026-11-25: project branding and/or documentation. Original XCL and third-party notices remain applicable.
//! Opt-in sampled resource pressure and live PSO spans. No scheduling or GPU policy changes.

use std::sync::{Mutex, OnceLock};
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Instant;

pub(crate) fn enabled() -> bool {
    static ON: OnceLock<bool> = OnceLock::new();
    *ON.get_or_init(|| std::env::var("CGBJ_PERF_TRACE").is_ok_and(|v| v == "1"))
}

struct Active {
    id: u64,
    key: usize,
    tid: u32,
    phase: &'static str,
    kind: &'static str,
    caller_builds: bool,
    started: Instant,
}

static ACTIVE: Mutex<Vec<Active>> = Mutex::new(Vec::new());

pub(crate) struct Scope(u64);

impl Scope {
    fn new(phase: &'static str, compute: bool, key: usize, caller_builds: bool) -> Self {
        static NEXT: AtomicU64 = AtomicU64::new(1);
        let id = NEXT.fetch_add(1, Ordering::Relaxed);
        ACTIVE.lock().unwrap().push(Active {
            id, key, tid: unsafe { windows_sys::Win32::System::Threading::GetCurrentThreadId() },
            phase, kind: if compute { "compute" } else { "graphics" }, caller_builds, started: Instant::now(),
        });
        Self(id)
    }
}

pub(crate) fn scope(phase: &'static str, compute: bool, key: usize, caller_builds: bool) -> Option<Scope> {
    enabled().then(|| Scope::new(phase, compute, key, caller_builds))
}

impl Drop for Scope {
    fn drop(&mut self) {
        let entry = {
            let mut active = ACTIVE.lock().unwrap();
            active.iter().position(|e| e.id == self.0).map(|i| active.swap_remove(i))
        };
        if let Some(e) = entry {
            let ms = e.started.elapsed().as_millis();
            if ms >= 1000 {
                crate::xlog_info!("perf slow: phase={} kind={} key={:#x} tid={} caller-builds={} elapsed_ms={ms}", e.phase, e.kind, e.key, e.tid, e.caller_builds);
            }
        }
    }
}

/// Called on the existing 2-second activity sampler. Up to 8 oldest live spans are
/// sampled each time; short completed jobs do not consume a lifetime log budget.
pub(crate) fn sample() {
    if !enabled() { return; }
    resources();
    super::critical_path::checkpoint();
    let mut spans = {
        let active = ACTIVE.lock().unwrap();
        let builds = active.iter().filter(|e| e.phase == "build").count();
        let waits = active.iter().filter(|e| e.phase == "wait").count();
        let rows: Vec<_> = active.iter().map(|e| (e.started.elapsed().as_millis(), e.phase, e.kind, e.key, e.tid, e.caller_builds)).collect();
        (builds, waits, rows)
    };
    crate::xlog_info!("perf jobs: builds={} waits={}", spans.0, spans.1);
    spans.2.sort_unstable_by(|a, b| b.0.cmp(&a.0));
    for (ms, phase, kind, key, tid, caller) in spans.2.into_iter().filter(|e| e.0 >= 1000).take(8) {
        crate::xlog_info!("perf active: phase={phase} kind={kind} key={key:#x} tid={tid} caller-builds={caller} age_ms={ms}");
    }
}

fn resources() {
    use windows_sys::Win32::Foundation::FILETIME;
    use windows_sys::Win32::System::ProcessStatus::{K32GetPerformanceInfo, K32GetProcessMemoryInfo, PERFORMANCE_INFORMATION, PROCESS_MEMORY_COUNTERS_EX};
    use windows_sys::Win32::System::Threading::{GetCurrentProcess, GetProcessTimes};
    let (mut m, mut s): (PROCESS_MEMORY_COUNTERS_EX, PERFORMANCE_INFORMATION) = unsafe { std::mem::zeroed() };
    m.cb = std::mem::size_of_val(&m) as u32;
    s.cb = std::mem::size_of_val(&s) as u32;
    let (mut created, mut exited, mut kernel, mut user) = (FILETIME::default(), FILETIME::default(), FILETIME::default(), FILETIME::default());
    let ok = unsafe {
        K32GetProcessMemoryInfo(GetCurrentProcess(), &mut m as *mut _ as *mut _, m.cb) != 0
            && K32GetPerformanceInfo(&mut s, s.cb) != 0
            && GetProcessTimes(GetCurrentProcess(), &mut created, &mut exited, &mut kernel, &mut user) != 0
    };
    if !ok { crate::xlog_info!("perf resources: unavailable"); return; }
    let ticks = |v: FILETIME| ((v.dwHighDateTime as u64) << 32) | v.dwLowDateTime as u64;
    let cpu = ticks(kernel).saturating_add(ticks(user));
    let sparse = super::sparse::perf_counters();
    static LAST: Mutex<Option<(Instant, u32, u64, [u64; 7])>> = Mutex::new(None);
    let previous = LAST.lock().unwrap().replace((Instant::now(), m.PageFaultCount, cpu, sparse));
    let (elapsed, faults, cores, delta) = match previous {
        Some((at, faults, old_cpu, old_sparse)) => {
            let elapsed = at.elapsed().as_secs_f64().max(0.000001);
            (elapsed, m.PageFaultCount.wrapping_sub(faults), cpu.saturating_sub(old_cpu) as f64 / 10_000_000.0 / elapsed,
                std::array::from_fn(|i| sparse[i].saturating_sub(old_sparse[i])))
        }
        None => (0.0, 0, 0.0, [0u64; 7]),
    };
    let video = super::real::video_memory_budget().map_or_else(|| "video=unavailable".to_owned(), |(local, nonlocal, budget, nonlocal_budget)| {
        format!("local_usage_mib={} local_budget_mib={} nonlocal_usage_mib={} nonlocal_budget_mib={}", local >> 20, budget >> 20, nonlocal >> 20, nonlocal_budget >> 20)
    });
    crate::xlog_info!("perf resources: interval_s={elapsed:.3} working_set_mib={} page_faults_delta={faults} cpu_cores={cores:.2} system_commit_free_mib={} physical_available_mib={} {video}",
        m.WorkingSetSize >> 20, s.CommitLimit.saturating_sub(s.CommitTotal).saturating_mul(s.PageSize) >> 20,
        s.PhysicalAvailable.saturating_mul(s.PageSize) >> 20);
    crate::xlog_info!("perf sparse: watch_ms={} dirty_pages={} lock_ms={} scan_ms={} upload_ms={} runs={} upload_mib={}",
        delta[0] / 1000, delta[1], delta[2] / 1000, delta[3] / 1000, delta[4] / 1000, delta[5], delta[6] >> 20);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn nested_build_and_wait_scopes_track_one_job_and_release_independently() {
        let wait = Scope::new("wait", true, 0x7f12_9001, true);
        let build = Scope::new("build", true, 0x7f12_9001, true);
        let (w, b) = (wait.0, build.0);
        {
            let active = ACTIVE.lock().unwrap();
            assert_eq!(active.iter().find(|e| e.id == w).unwrap().key, active.iter().find(|e| e.id == b).unwrap().key);
            assert_eq!(active.iter().find(|e| e.id == w).unwrap().phase, "wait");
            assert_eq!(active.iter().find(|e| e.id == b).unwrap().phase, "build");
        }
        drop(build);
        assert!(!ACTIVE.lock().unwrap().iter().any(|e| e.id == b));
        assert!(ACTIVE.lock().unwrap().iter().any(|e| e.id == w));
        drop(wait);
        assert!(!ACTIVE.lock().unwrap().iter().any(|e| e.id == w));
    }

    #[test]
    fn unwinding_a_build_does_not_leave_a_phantom_active_job() {
        let id = std::sync::atomic::AtomicU64::new(0);
        let result = std::panic::catch_unwind(|| {
            let scope = Scope::new("build", false, 0x7f12_9002, false);
            id.store(scope.0, Ordering::Relaxed);
            panic!("synthetic unwind");
        });
        assert!(result.is_err());
        assert!(!ACTIVE.lock().unwrap().iter().any(|e| e.id == id.load(Ordering::Relaxed)));
    }
}
