// Modified for the CGBJ fork on 2026-11-25: project branding and/or documentation. Original XCL and third-party notices remain applicable.
//! Bounded CPU recording/submission evidence, never a GPU completion or scheduling policy.
use std::collections::{HashMap, VecDeque};
use std::sync::{Mutex, OnceLock};

const CAPACITY: usize = 8192;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum Kind {
    Created { ty: i32 },
    Reset,
    Release,
    Write { va: u64, width: u8, value: u64 },
    Mesh,
    PsoWait { pso: usize },
    PsoReady,
    MemoryWait { va: u64, width: u8, op: u32, value: u64 },
    ComputeUse { pso: usize, shader: u64, build: usize },
    ReplayRequested,
    ReplayBegin,
    CloseBegin,
    CloseEnd { hr: i32 },
    Admission { queue: usize, original: usize, batch: u64 },
    Requested { queue: usize },
    NativeEnter { queue: usize, batch: u64 },
    Submitted { queue: usize },
}

#[derive(Clone, Copy, Debug, Default)]
struct Lifecycle {
    object_id: u64,
    ty: Option<i32>,
    replay: Option<Event>,
    replay_request: Option<Event>,
    close: Option<Event>,
    admission: Option<Event>,
    requested: Option<Event>,
    native_enter: Option<Event>,
    submitted: Option<Event>,
    bind: Option<Event>,
    wait_count: u32,
    waits: [Option<Event>; 4],
}

#[derive(Clone, Copy, Debug)]
struct FenceEdge { sequence: u64, tid: u32, queue: usize, fence: usize, value: u64, signal: bool, hr: Option<i32>, completed: Option<u64> }

#[derive(Clone, Copy, Debug)]
struct Queue { id: u64, device: usize, ty: i32 }

#[derive(Clone, Copy, Debug)]
pub(super) struct Event {
    sequence: u64,
    list: usize,
    recording: u64,
    tid: u32,
    kind: Kind,
    queue: Option<Queue>,
}

#[derive(Default)]
struct History {
    sequence: u64,
    next_recording: u64,
    recordings: HashMap<usize, u64>,
    events: VecDeque<Event>,
    evicted: u64,
    next_object: u64,
    objects: HashMap<usize, (u64, Option<i32>)>,
    states: HashMap<u64, Lifecycle>,
    state_order: VecDeque<u64>,
    writes: HashMap<(u64, u8), Event>,
    write_order: VecDeque<(u64, u8)>,
    queues: HashMap<usize, Queue>,
    next_queue: u64,
    active_submissions: HashMap<u32, (u64, usize, &'static str)>,
    watched: std::collections::HashSet<u64>,
    scene_watched: std::collections::HashSet<u64>,
    aliases: HashMap<usize, usize>,
    fences: VecDeque<FenceEdge>,
    latest_mesh: Option<Event>,
    scene_started: bool,
    checkpoint_count: u64,
    compute_uses: HashMap<u64, Vec<(usize, u64, usize)>>,
    audit_recorded: std::collections::HashSet<u64>,
    audit_submitted: std::collections::HashSet<u64>,
}

impl History {
    fn next_checkpoint(&mut self) -> Option<u64> {
        if !self.scene_started { return None; }
        self.checkpoint_count += 1;
        let n = self.checkpoint_count;
        (n <= 16 || n.is_power_of_two()).then_some(n)
    }
    fn push(&mut self, list: usize, tid: u32, kind: Kind) {
        if matches!(kind, Kind::Created { .. }) || !self.objects.contains_key(&list) {
            if self.objects.len() >= CAPACITY {
                self.objects.clear(); self.recordings.clear(); self.states.clear(); self.state_order.clear();
                self.compute_uses.clear();
                self.events.clear(); self.evicted += 1;
            }
            self.next_object += 1;
            let ty = if let Kind::Created { ty } = kind { Some(ty) } else { None };
            self.objects.insert(list, (self.next_object, ty));
            self.aliases.remove(&list);
        }
        if matches!(kind, Kind::Reset | Kind::Created { .. }) || !self.recordings.contains_key(&list) {
            self.next_recording += 1;
            if self.recordings.len() >= CAPACITY {
                self.recordings.clear();
                self.events.clear();
                self.evicted += 1;
            }
            self.recordings.insert(list, self.next_recording);
            if self.state_order.len() == CAPACITY {
                if let Some(old) = self.state_order.pop_front() { self.states.remove(&old); self.compute_uses.remove(&old); }
            }
            self.state_order.push_back(self.next_recording);
            let (object_id, ty) = self.objects[&list];
            self.states.insert(self.next_recording, Lifecycle { object_id, ty, ..Default::default() });
        }
        self.sequence += 1;
        let queue = match kind {
            Kind::Admission { queue, .. } | Kind::Requested { queue } | Kind::NativeEnter { queue, .. } | Kind::Submitted { queue } => self.queues.get(&queue).copied(),
            _ => None,
        };
        let e = Event { sequence: self.sequence, list, recording: self.recordings[&list], tid, kind, queue };
        if self.events.len() == CAPACITY { self.events.pop_front(); self.evicted += 1; }
        self.events.push_back(e);
        if let Kind::ComputeUse { pso, shader, build } = kind {
            let uses = self.compute_uses.entry(e.recording).or_default();
            if uses.len() < 256 && !uses.contains(&(pso, shader, build)) { uses.push((pso, shader, build)); }
        }
        if kind == Kind::Mesh { self.latest_mesh = Some(e); }
        if let Some(s) = self.states.get_mut(&e.recording) {
            match kind {
                Kind::MemoryWait { .. } => {
                    if s.wait_count < 4 { s.waits[s.wait_count as usize] = Some(e); }
                    s.wait_count += 1;
                }
                Kind::ReplayRequested => s.replay_request = Some(e),
                Kind::ReplayBegin => s.replay = Some(e),
                Kind::CloseBegin | Kind::CloseEnd { .. } => s.close = Some(e),
                Kind::Admission { .. } => s.admission = Some(e),
                Kind::Requested { .. } => s.requested = Some(e),
                Kind::NativeEnter { .. } => s.native_enter = Some(e),
                Kind::Submitted { .. } => s.submitted = Some(e),
                Kind::PsoWait { .. } | Kind::PsoReady => s.bind = Some(e),
                _ => {}
            }
        }
        if let Kind::Write { va, width, .. } = kind {
            let key = (va, width);
            if !self.writes.contains_key(&key) {
                if self.write_order.len() == CAPACITY {
                    if let Some(old) = self.write_order.pop_front() { self.writes.remove(&old); }
                }
                self.write_order.push_back(key);
            }
            self.writes.insert(key, e);
        }
        if kind == Kind::Release { self.recordings.remove(&list); self.objects.remove(&list); }
    }

    fn producer(&self, va: u64, width: u8) -> Option<Event> {
        self.writes.get(&(va, width)).copied()
    }

    fn blocked_bindings(&self) -> Vec<(Event, Lifecycle)> {
        let mut rows: Vec<_> = self.recordings.values().filter_map(|r| {
            let s = *self.states.get(r)?;
            let e = s.bind?;
            matches!(e.kind, Kind::PsoWait { .. }).then_some((e, s))
        }).collect();
        rows.sort_unstable_by_key(|(e, _)| e.sequence);
        rows.truncate(16);
        rows
    }

    fn last_stage(&self, event: Event, native: bool) -> Option<Event> {
        let s = self.states.get(&event.recording)?;
        (if native { s.submitted } else { s.requested }).filter(|e| e.sequence > event.sequence)
    }

    fn invalidated(&self, event: Event) -> bool {
        self.recordings.get(&event.list).copied() != Some(event.recording)
    }
}

pub(super) fn enabled() -> bool {
    static ON: OnceLock<bool> = OnceLock::new();
    *ON.get_or_init(|| std::env::var("CGBJ_CRITICAL_PATH").is_ok_and(|v| v == "1"))
}

fn history() -> &'static Mutex<History> {
    static HISTORY: OnceLock<Mutex<History>> = OnceLock::new();
    HISTORY.get_or_init(|| Mutex::new(History::default()))
}

/// Bounded periodic evidence after loading begins, even when no new memory wait occurs.
pub(super) fn checkpoint() {
    if !enabled() { return; }
    let (n, blocked, mesh, active) = {
        let Ok(mut h) = history().try_lock() else { return };
        let Some(n) = h.next_checkpoint() else { return };
        let blocked = h.blocked_bindings();
        for (e, s) in &blocked {
            if s.close.is_none() && h.scene_watched.len() < 16 { h.scene_watched.insert(e.recording); }
        }
        (n, blocked, h.latest_mesh.map(|e| (e, h.states.get(&e.recording).copied())),
            h.active_submissions.iter().take(16).map(|(t, s)| (*t, *s)).collect::<Vec<_>>())
    };
    crate::xlog_info!("critical-checkpoint #{n}: latest_mesh={mesh:x?} active_submissions={active:x?}");
    for (event, state) in blocked {
        if let Kind::PsoWait { pso } = event.kind {
            crate::xlog_info!("critical-recording-block #{n}: event={event:x?} state={state:x?} {}", super::pso_async::diagnostic(pso));
        }
    }
    crate::xlog_info!("critical-queue-progress #{n}: (queue,requested,completed)={:x?}; private CPU-write fences only", super::cpu_writes::queue_progress());
    super::pipeline_audit::sample();
}

pub(super) fn record(list: usize, kind: Kind) {
    if !enabled() { return; }
    let mut h = history().lock().unwrap();
    let old = h.recordings.get(&list).copied();
    h.push(list, unsafe { windows_sys::Win32::System::Threading::GetCurrentThreadId() }, kind);
    if let Some(e) = h.events.back().copied() {
        if let Kind::ComputeUse { shader, .. } = kind {
            if h.audit_recorded.len() < CAPACITY && h.audit_recorded.insert(shader) {
                super::pipeline_audit::event("compute-recorded", format_args!("event={e:x?}; first shader use, not GPU completion"));
            }
        } else if matches!(kind, Kind::Submitted { .. }) {
            let uses: Vec<_> = h.compute_uses.get(&e.recording).cloned().unwrap_or_default().into_iter()
                .filter(|(_, shader, _)| h.audit_submitted.len() < CAPACITY && h.audit_submitted.insert(*shader)).collect();
            if !uses.is_empty() {
                super::pipeline_audit::event("compute-submitted", format_args!("event={e:x?} uses={uses:x?}; native return is not GPU completion"));
            }
        }
    }
    let id = h.recordings.get(&list).copied().or(old);
    let interesting = matches!(kind, Kind::CloseBegin | Kind::CloseEnd { .. } | Kind::ReplayBegin | Kind::ReplayRequested
        | Kind::Admission { .. } | Kind::Requested { .. } | Kind::NativeEnter { .. } | Kind::Submitted { .. }
        | Kind::Reset | Kind::Release | Kind::Created { .. });
    if interesting && id.into_iter().chain(old).any(|r| h.scene_watched.contains(&r)) {
        use std::sync::atomic::{AtomicU64, Ordering};
        static SCENE_LINES: AtomicU64 = AtomicU64::new(0);
        let n = SCENE_LINES.fetch_add(1, Ordering::Relaxed);
        if n < 256 {
            crate::xlog_info!("critical-recording-transition: old_recording={old:x?} event={:x?}", h.events.back());
        } else if n == 256 {
            crate::xlog_warn!("critical-recording-transition quota exhausted; later absence is unknown");
        }
    }
    if interesting && id.into_iter().chain(old).any(|r| h.watched.contains(&r)) {
        use std::sync::atomic::{AtomicU64, Ordering};
        static N: AtomicU64 = AtomicU64::new(0);
        if N.fetch_add(1, Ordering::Relaxed) < 128 {
            crate::xlog_info!("critical-producer-transition: old_recording={old:x?} event={:x?}", h.events.back());
        }
    }
}

pub(super) fn queue_created(queue: usize, device: usize, ty: i32) {
    if !enabled() { return; }
    let mut h = history().lock().unwrap();
    h.next_queue += 1;
    let id = h.next_queue;
    if h.queues.len() >= CAPACITY { h.queues.clear(); }
    h.queues.insert(queue, Queue { id, device, ty });
}

pub(super) fn alias(original: usize, native: usize) {
    if !enabled() { return; }
    let mut h = history().lock().unwrap();
    if h.aliases.len() >= CAPACITY { h.aliases.clear(); }
    h.aliases.insert(original, native);
}

pub(super) fn backing(original: usize) -> Option<usize> {
    if !enabled() { return None; }
    history().lock().unwrap().aliases.get(&original).copied()
}

pub(super) fn fence(queue: usize, fence: usize, value: u64, signal: bool, hr: Option<i32>, completed: Option<u64>) {
    if !enabled() { return; }
    let mut h = history().lock().unwrap();
    h.sequence += 1;
    let edge = FenceEdge { sequence: h.sequence, tid: unsafe { windows_sys::Win32::System::Threading::GetCurrentThreadId() }, queue, fence, value, signal, hr, completed };
    if h.fences.len() == 64 { h.fences.pop_front(); }
    h.fences.push_back(edge);
}

pub(super) fn batch() -> u64 {
    use std::sync::atomic::{AtomicU64, Ordering};
    static N: AtomicU64 = AtomicU64::new(1);
    N.fetch_add(1, Ordering::Relaxed)
}

pub(super) fn submission_stage(batch: u64, queue: usize, stage: &'static str) {
    if !enabled() { return; }
    let mut h = history().lock().unwrap();
    let tid = unsafe { windows_sys::Win32::System::Threading::GetCurrentThreadId() };
    if stage == "returned" { h.active_submissions.remove(&tid); }
    else {
        if h.active_submissions.len() >= CAPACITY { h.active_submissions.clear(); }
        h.active_submissions.insert(tid, (batch, queue, stage));
    }
}

fn queue_of(e: Event) -> Option<usize> {
    match e.kind {
        Kind::Admission { queue, .. } | Kind::Requested { queue } | Kind::NativeEnter { queue, .. } | Kind::Submitted { queue } => Some(queue),
        _ => None,
    }
}

/// Sparse diagnostic: absence means only "not observed in retained explicit writes".
/// Shader stores, bundles and command lists not reaching these hooks are not attributed.
pub(super) fn waiting(list: usize, va: u64, width: u8, value: u64) {
    use std::sync::atomic::{AtomicU64, Ordering};
    if !enabled() { return; }
    static N: AtomicU64 = AtomicU64::new(0);
    let n = N.fetch_add(1, Ordering::Relaxed) + 1;
    if n > 16 && !n.is_power_of_two() { return; }
    let mut h = history().lock().unwrap();
    let producer = h.producer(va, width);
    h.scene_started = true;
    if h.watched.len() < 16 { if let Some(p) = producer { h.watched.insert(p.recording); } }
    let lifecycle = producer.and_then(|p| h.states.get(&p.recording)).copied();
    let queues: Vec<_> = lifecycle.map_or(Vec::new(), |s| [s.admission, s.requested, s.native_enter, s.submitted]
        .into_iter().flatten().filter_map(|e| queue_of(e).map(|q| (q, e.queue.map(|q| (q.id, q.device, q.ty))))).collect());
    let waiter_tail: Vec<_> = h.events.iter().rev().filter(|e| e.list == list).take(3).copied().collect();
    let requested = producer.and_then(|e| h.last_stage(e, false));
    let submitted = producer.and_then(|e| h.last_stage(e, true));
    let invalidated = producer.is_some_and(|e| h.invalidated(e));
    let mesh = h.events.iter().rev().find(|e| e.kind == Kind::Mesh).copied();
    let mesh_submit = mesh.and_then(|e| h.last_stage(e, true));
    let producer_tail: Vec<_> = producer.map_or(Vec::new(), |p| h.events.iter().rev()
        .filter(|e| e.list == p.list && e.recording == p.recording).take(4).copied().collect());
    crate::xlog_info!("critical-path wait #{n}: waiter={list:#x} va={va:#x} width={width} want={value:#x} producer={producer:x?} requested={requested:x?} native_submit={submitted:x?} invalidated={invalidated} producer_tail={producer_tail:x?} waiter_tail={waiter_tail:x?} latest_mesh={mesh:x?} mesh_native_submit={mesh_submit:x?} evicted={}; no fence completion inferred", h.evicted);
    crate::xlog_info!("critical-lifecycle #{n}: producer_tid={:?} object_id={:?} list_type={:?} state={lifecycle:x?} queues={queues:x?} waiter_state={:x?}; missing state means unknown, not unsubmitted", producer.map(|p| p.tid), lifecycle.map(|s| s.object_id), lifecycle.and_then(|s| s.ty), h.recordings.get(&list).and_then(|r| h.states.get(r)));
    crate::xlog_info!("critical-submissions #{n}: active={:x?}", h.active_submissions.iter().take(16).collect::<Vec<_>>());
    // Native queue Signal/Wait are observations, never CPU completion publications.
    let fences: Vec<_> = h.fences.iter().rev().take(12).map(|e| (e.sequence,e.tid,e.queue,e.fence,e.value,e.signal,e.hr,e.completed)).collect();
    crate::xlog_info!("critical-fences #{n}: (seq,tid,queue,fence,value,signal,hr,completed)={fences:x?}");
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn menu_time_does_not_consume_scene_checkpoints() {
        let mut h = History::default();
        for _ in 0..1000 { assert_eq!(h.next_checkpoint(), None); }
        h.scene_started = true;
        for n in 1..=16 { assert_eq!(h.next_checkpoint(), Some(n)); }
        for _ in 17..32 { assert_eq!(h.next_checkpoint(), None); }
        assert_eq!(h.next_checkpoint(), Some(32));
    }
    #[test]
    fn compute_uses_follow_recording_not_reused_list_address() {
        let mut h = History::default();
        h.push(1, 1, Kind::ComputeUse { pso: 10, shader: 11, build: 12 });
        let old = h.recordings[&1];
        h.push(1, 1, Kind::ComputeUse { pso: 10, shader: 11, build: 12 });
        assert_eq!(h.compute_uses[&old], vec![(10,11,12)]);
        h.push(1, 1, Kind::Reset);
        assert!(!h.compute_uses.contains_key(&h.recordings[&1]));
        h.push(1, 1, Kind::ComputeUse { pso: 20, shader: 21, build: 22 });
        assert_eq!(h.compute_uses[&h.recordings[&1]], vec![(20,21,22)]);
    }

    #[test]
    fn checkpoint_excludes_ready_reset_released_and_expired_bindings() {
        let mut h = History::default();
        h.push(1, 10, Kind::PsoWait { pso: 100 });
        h.push(2, 20, Kind::PsoWait { pso: 200 });
        assert_eq!(h.blocked_bindings().len(), 2);
        h.push(1, 10, Kind::PsoReady);
        assert_eq!(h.blocked_bindings()[0].0.list, 2);
        h.push(2, 20, Kind::Reset);
        assert!(h.blocked_bindings().is_empty());
        h.push(2, 20, Kind::PsoWait { pso: 201 });
        h.push(2, 20, Kind::Release);
        assert!(h.blocked_bindings().is_empty());
        h.push(3, 30, Kind::PsoWait { pso: 300 });
        h.states.clear();
        assert!(h.blocked_bindings().is_empty());
    }

    #[test]
    fn producer_requires_submission_of_its_recording_not_a_reused_list() {
        let mut h = History::default();
        h.push(1, 11, Kind::Reset);
        h.push(1, 11, Kind::Write { va: 0x1000, width: 8, value: 42 });
        let old = h.producer(0x1000, 8).unwrap();
        assert_eq!(old.tid, 11);
        h.push(1, 12, Kind::Requested { queue: 4 });
        assert!(h.last_stage(old, false).is_some());
        assert!(h.last_stage(old, true).is_none(), "requested is not submitted");
        h.push(1, 11, Kind::Reset);
        h.push(1, 12, Kind::Submitted { queue: 4 });
        assert!(h.last_stage(old, true).is_none(), "new recording cannot complete an old producer");
        assert!(h.invalidated(old));
        h.push(1, 13, Kind::Write { va: 0x1000, width: 8, value: 43 });
        let new = h.producer(0x1000, 8).unwrap();
        assert!(h.last_stage(new, true).is_none(), "earlier submission cannot submit a later write");
        h.push(1, 14, Kind::Submitted { queue: 5 });
        assert!(h.last_stage(new, true).is_some());
        assert!(h.producer(0x1000, 4).is_none(), "widths must match");
        h.push(1, 14, Kind::Release);
        assert!(h.invalidated(new));
    }

    #[test]
    fn retained_history_is_bounded_and_keeps_producer_lifecycle_after_event_eviction() {
        let mut h = History::default();
        h.push(1, 0, Kind::Write { va: 0x1000, width: 8, value: 1 });
        for _ in 0..CAPACITY { h.push(1, 0, Kind::PsoReady); }
        assert_eq!(h.events.len(), CAPACITY);
        assert_eq!(h.evicted, 1);
        assert!(h.producer(0x1000, 8).is_some(), "explicit producer metadata outlives verbose events");
        for _ in 0..CAPACITY { h.push(1, 0, Kind::Reset); }
        assert!(h.states.get(&h.producer(0x1000, 8).unwrap().recording).is_none(), "expired lifecycle is unknown");
        assert_eq!(h.states.len(), CAPACITY);
    }

    #[test]
    fn lifecycle_distinguishes_close_admission_native_entry_and_reused_objects() {
        let mut h = History::default();
        h.queues.insert(4, Queue { id: 40, device: 9, ty: 2 });
        h.push(1, 11, Kind::Created { ty: 0 });
        h.aliases.insert(7, 1);
        h.push(1, 11, Kind::Write { va: 8, width: 8, value: 7 });
        let p = h.producer(8, 8).unwrap();
        h.push(1, 12, Kind::CloseBegin);
        h.push(1, 12, Kind::CloseEnd { hr: -1 });
        h.push(1, 13, Kind::Admission { queue: 4, original: 9, batch: 6 });
        assert_eq!(h.states[&p.recording].close.unwrap().kind, Kind::CloseEnd { hr: -1 });
        assert!(h.states[&p.recording].requested.is_none(), "admission is before texture refresh/waits");
        h.push(1, 13, Kind::Requested { queue: 4 });
        h.push(1, 13, Kind::NativeEnter { queue: 4, batch: 6 });
        assert!(h.last_stage(p, true).is_none(), "entering native call is not its return");
        let object = h.states[&p.recording].object_id;
        assert_eq!(h.states[&p.recording].ty, Some(0));
        h.push(1, 13, Kind::Submitted { queue: 4 });
        assert!(h.last_stage(p, true).is_some());
        h.queues.insert(4, Queue { id: 41, device: 9, ty: 0 });
        assert_eq!(h.last_stage(p, true).unwrap().queue.unwrap().id, 40, "queue address reuse must not rewrite old routing evidence");
        assert_eq!(h.last_stage(p, true).unwrap().queue.unwrap().ty, 2);
        h.push(1, 13, Kind::Release);
        h.push(1, 13, Kind::Created { ty: 2 });
        let new = h.states[&h.recordings[&1]];
        assert_ne!(new.object_id, object);
        assert!(new.close.is_none() && new.submitted.is_none());
        h.push(7, 13, Kind::Created { ty: 0 });
        assert!(!h.aliases.contains_key(&7), "a new native object cannot inherit a former wrapper alias");
    }

    #[test]
    fn producer_reverse_waits_are_recorded_in_order_with_bounded_details() {
        let mut h = History::default();
        h.push(1, 2, Kind::Created { ty: 0 });
        h.push(1, 2, Kind::Write { va: 0x1000, width: 8, value: 7 });
        let p = h.producer(0x1000, 8).unwrap();
        for i in 0..6 { h.push(1, 2, Kind::MemoryWait { va: 0x1008 + i * 16, width: 8, op: 7, value: 7 }); }
        let s = h.states[&p.recording];
        assert_eq!(s.wait_count, 6);
        assert_eq!(s.waits.iter().flatten().count(), 4);
        assert!(s.waits[0].unwrap().sequence > p.sequence);
        h.push(1, 2, Kind::Reset);
        assert_eq!(h.states[&h.recordings[&1]].wait_count, 0);
    }
}
