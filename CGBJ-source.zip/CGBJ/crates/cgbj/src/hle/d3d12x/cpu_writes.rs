// Modified for the CGBJ fork on 2026-11-25: project branding and/or documentation. Original XCL and third-party notices remain applicable.
//! Write32/64BitValueBottomOfPipeX into memory the GPU does not see: done by the CPU once the GPU
//! has finished the work before them.
//!
//! A console title marks its GPU progress with bottom-of-pipe writes into its own memory and
//! waits on them (a retail game: plain `VirtualAlloc` memory, outside CGBJ's unified memory).
//! The PC GPU cannot write there; dropped, the title waited for ever after its second frame.
//! Here each queue gets a fence of CGBJ's: after a submission whose lists carry such writes the
//! queue signals it, and a worker thread does the writes, in submission order, when the GPU is
//! there – what bottom of pipe means.

use std::collections::{HashMap, VecDeque};
use std::ffi::c_void;
use std::sync::atomic::{AtomicU32, AtomicU64, Ordering};
use std::sync::{mpsc, Mutex, OnceLock};

use windows::core::Interface;
use windows::Win32::Graphics::Direct3D12::*;

/// A bottom-of-pipe write into memory outside unified memory, applied by the CPU once the
/// queue's fence reaches the submission that recorded it.
#[derive(Clone)]
pub(super) enum Write {
    /// Immediate dwords to store starting at `va`.
    Immediate(usize, Vec<u32>),
    /// A 64-bit value resolved by the GPU into a persistently mapped READBACK buffer slot
    /// (`src`), copied atomically to `va` once the queue's fence completes. Holding `_buf` keeps
    /// the mapping alive until the worker finishes.
    ReadbackU64 { va: usize, src: usize, _buf: ID3D12Resource },
    /// Private readback and all objects it needs remain alive through confirmed completion.
    Inspect(ReadbackInspection),
}

#[derive(Clone)]
pub(super) struct ReadbackInspection {
    pub readback: ID3D12Resource,
    pub dwords: u32,
    pub callback: fn(&[u32]),
    pub _resources: Vec<ID3D12Resource>,
    pub _pipelines: Vec<ID3D12PipelineState>,
}

unsafe fn inspect(value: &ReadbackInspection) {
    let bytes = value.dwords as u64 * 4;
    if bytes == 0 || bytes > value.readback.GetDesc().Width {
        crate::xlog_error!("D3D12.X: invalid GPU inspection readback length");
        return;
    }
    let mut mapped = std::ptr::null_mut();
    match value.readback.Map(0, None, Some(&mut mapped)) {
        Ok(()) => {
            (value.callback)(std::slice::from_raw_parts(mapped as *const u32, value.dwords as usize));
            value.readback.Unmap(0, None);
        }
        Err(e) => crate::xlog_error!("D3D12.X: GPU inspection readback Map failed: {e}"),
    }
}

struct Job {
    fence: ID3D12Fence,
    value: u64,
    writes: Vec<Write>,
}

// SAFETY: the fence is a free-threaded COM object; the writes are plain data
unsafe impl Send for Job {}

/// queue → its fence and the last value signalled
struct QueueFence {
    fence: ID3D12Fence,
    value: u64,
}

unsafe impl Send for QueueFence {}

static FENCES: Mutex<Option<HashMap<usize, QueueFence>>> = Mutex::new(None);

/// Live references protect native fence queries; never inspect historical raw fence pointers.
pub(super) fn queue_progress() -> Option<Vec<(usize, u64, u64)>> {
    let rows: Vec<_> = {
        let g = FENCES.try_lock().ok()?;
        g.as_ref().into_iter().flat_map(|m| m.iter()).take(16)
            .map(|(q, f)| (*q, f.value, f.fence.clone())).collect()
    };
    Some(rows.into_iter().map(|(q, value, f)| unsafe {
        let completed = if super::real::is_adopted(f.as_raw()) {
            let get: unsafe extern "system" fn(*mut c_void) -> u64 = std::mem::transmute(super::real::orig_fn(f.as_raw(), 8));
            get(f.as_raw())
        } else { f.GetCompletedValue() };
        (q, value, completed)
    }).collect())
}

/// Warn after this long, but never publish a pending submission as though it completed.
const WAIT_MS: u32 = 10_000;

fn worker() -> &'static Mutex<mpsc::Sender<Job>> {
    static W: OnceLock<Mutex<mpsc::Sender<Job>>> = OnceLock::new();
    W.get_or_init(|| {
        let (tx, rx) = mpsc::channel::<Job>();
        let spawned = std::thread::Builder::new().name("cgbj-cpu-writes".into()).spawn(move || unsafe {
            // One FIFO per private queue fence. A stalled producer retains its suffix while
            // independent queues can publish; no extra thread or event per queue is needed.
            let mut pending: HashMap<usize, (VecDeque<Job>, std::time::Instant, bool)> = HashMap::new();
            loop {
                let incoming = if pending.is_empty() {
                    match rx.recv() { Ok(job) => Some(job), Err(_) => break }
                } else {
                    match rx.recv_timeout(std::time::Duration::from_millis(5)) {
                        Ok(job) => Some(job),
                        Err(mpsc::RecvTimeoutError::Timeout) => None,
                        Err(mpsc::RecvTimeoutError::Disconnected) => break,
                    }
                };
                if let Some(job) = incoming {
                    pending.entry(job.fence.as_raw() as usize)
                        .or_insert_with(|| (VecDeque::new(), std::time::Instant::now(), false)).0.push_back(job);
                }
                pending.retain(|&key, (jobs, since, warned)| {
                    while let Some(job) = jobs.front() {
                        let completed = job.fence.GetCompletedValue();
                        if completed == u64::MAX {
                            crate::xlog_warn!("D3D12.X: removed-device fence {key:#x}: dropping {} unpublished CPU-write submissions", jobs.len());
                            jobs.clear();
                            break;
                        }
                        if completed < job.value {
                            if !*warned && since.elapsed().as_millis() >= WAIT_MS as u128 {
                                crate::xlog_warn!("D3D12.X: CPU writes retained for fence {key:#x} value {} (completed {completed}) after {WAIT_MS} ms; not published early", job.value);
                                *warned = true;
                            }
                            break;
                        }
                        let job = jobs.pop_front().unwrap();
                        for w in &job.writes {
                            match w {
                                Write::Immediate(va, words) => write_now(*va, words),
                                Write::ReadbackU64 { va, src, .. } => {
                                    let value = (*(*src as *const AtomicU64)).load(Ordering::Acquire);
                                    write_u64_now(*va, value);
                                }
                                Write::Inspect(value) => inspect(value),
                            }
                        }
                        *since = std::time::Instant::now();
                        *warned = false;
                    }
                    !jobs.is_empty()
                });
            }
        });
        if let Err(e) = spawned {
            crate::xlog_error!("D3D12.X: no thread for the writes after the GPU: {e}");
        }
        Mutex::new(tx)
    })
}

/// The dwords at `va`, if the memory is still there and writable.
unsafe fn write_now(va: usize, words: &[u32]) {
    use windows_sys::Win32::System::Memory::{VirtualQuery, MEMORY_BASIC_INFORMATION, MEM_COMMIT, PAGE_EXECUTE_READWRITE, PAGE_READWRITE};
    let mut m: MEMORY_BASIC_INFORMATION = std::mem::zeroed();
    if VirtualQuery(va as *const c_void, &mut m, std::mem::size_of_val(&m)) == 0 || m.State != MEM_COMMIT {
        return;
    }
    if m.Protect & (PAGE_READWRITE | PAGE_EXECUTE_READWRITE) == 0 || (m.BaseAddress as usize + m.RegionSize) < va + 4 * words.len() {
        return;
    }
    for (i, &w) in words.iter().enumerate() {
        (*((va + 4 * i) as *const AtomicU32)).store(w, Ordering::Release);
    }
}

/// An 8-byte aligned 64-bit value at `va`, if the memory is still there and writable.
unsafe fn write_u64_now(va: usize, value: u64) {
    use windows_sys::Win32::System::Memory::{VirtualQuery, MEMORY_BASIC_INFORMATION, MEM_COMMIT, PAGE_EXECUTE_READWRITE, PAGE_GUARD, PAGE_READWRITE};
    let Some(end) = va.checked_add(8) else { return };
    let mut m: MEMORY_BASIC_INFORMATION = std::mem::zeroed();
    if VirtualQuery(va as *const c_void, &mut m, std::mem::size_of_val(&m)) == 0 || m.State != MEM_COMMIT {
        return;
    }
    if m.Protect & PAGE_GUARD != 0 || m.Protect & (PAGE_READWRITE | PAGE_EXECUTE_READWRITE) == 0 || (m.BaseAddress as usize).saturating_add(m.RegionSize) < end {
        return;
    }
    (*(va as *const AtomicU64)).store(value, Ordering::Release);
}

/// Whether `[va, va + bytes)` is memory the CPU can write for the GPU later.
pub(super) fn writable(va: usize, bytes: usize) -> bool {
    crate::hle::kernelx::lazy::ensure(va, bytes);
    use windows_sys::Win32::System::Memory::{VirtualQuery, MEMORY_BASIC_INFORMATION, MEM_COMMIT, PAGE_EXECUTE_READWRITE, PAGE_READWRITE};
    let mut m: MEMORY_BASIC_INFORMATION = unsafe { std::mem::zeroed() };
    let found = unsafe { VirtualQuery(va as *const c_void, &mut m, std::mem::size_of_val(&m)) } != 0;
    found
        && m.State == MEM_COMMIT
        && m.Protect & (PAGE_READWRITE | PAGE_EXECUTE_READWRITE) != 0
        && m.BaseAddress as usize + m.RegionSize >= va + bytes
}

/// `writes` of lists just submitted to `queue`: done when the GPU has finished them.
pub(super) unsafe fn after(queue: *mut c_void, writes: Vec<Write>) {
    if writes.is_empty() || queue.is_null() {
        return;
    }
    let Some(q) = ID3D12CommandQueue::from_raw_borrowed(&queue) else { return };
    // Keep fence values and channel admission in the same order, including concurrent callers.
    let mut g = FENCES.lock().unwrap();
    let job = {
        let m = g.get_or_insert_with(HashMap::new);
        let entry = match m.entry(queue as usize) {
            std::collections::hash_map::Entry::Occupied(e) => e.into_mut(),
            std::collections::hash_map::Entry::Vacant(v) => {
                let mut dev: Option<ID3D12Device> = None;
                if q.GetDevice(&mut dev).is_err() {
                    return;
                }
                let Some(dev) = dev else { return };
                let Ok(fence) = dev.CreateFence::<ID3D12Fence>(0, D3D12_FENCE_FLAG_NONE) else { return };
                v.insert(QueueFence { fence, value: 0 })
            }
        };
        entry.value += 1;
        if q.Signal(&entry.fence, entry.value).is_err() {
            return;
        }
        Job { fence: entry.fence.clone(), value: entry.value, writes }
    };
    static FIRST: std::sync::Once = std::sync::Once::new();
    FIRST.call_once(|| crate::xlog_info!("D3D12.X: bottom-of-pipe writes outside unified memory are done by the CPU after the GPU ({} in the first submission)", job.writes.len()));
    let _ = worker().lock().unwrap().send(job);
    drop(g);
}

#[cfg(test)]
mod tests {
    use super::*;
    use windows::Win32::Graphics::Direct3D::D3D_FEATURE_LEVEL_11_0;
    use windows::Win32::Graphics::Dxgi::*;

    #[test]
    fn private_readback_inspection_waits_for_gpu_copy_and_queue_completion() {
        static SEEN: AtomicU32 = AtomicU32::new(0);
        fn inspect(words: &[u32]) { SEEN.store(words[0], Ordering::Release); }
        unsafe {
            let Ok(dev) = crate::gpu::agility::create_device(None, D3D_FEATURE_LEVEL_11_0) else {
                return crate::gpu::recomp::runner::skip_test("no GPU for private readback");
            };
            let q: ID3D12CommandQueue = dev.CreateCommandQueue(&D3D12_COMMAND_QUEUE_DESC::default()).unwrap();
            let gate: ID3D12Fence = dev.CreateFence(0, D3D12_FENCE_FLAG_NONE).unwrap();
            let buffer = |heap, state| {
                let desc = D3D12_RESOURCE_DESC { Dimension: D3D12_RESOURCE_DIMENSION_BUFFER, Width: 256, Height: 1,
                    DepthOrArraySize: 1, MipLevels: 1, SampleDesc: windows::Win32::Graphics::Dxgi::Common::DXGI_SAMPLE_DESC { Count: 1, Quality: 0 },
                    Layout: D3D12_TEXTURE_LAYOUT_ROW_MAJOR, ..Default::default() };
                let mut resource: Option<ID3D12Resource> = None;
                dev.CreateCommittedResource(&D3D12_HEAP_PROPERTIES { Type: heap, ..Default::default() },
                    D3D12_HEAP_FLAG_NONE, &desc, state, None, &mut resource).unwrap();
                resource.unwrap()
            };
            let upload = buffer(D3D12_HEAP_TYPE_UPLOAD, D3D12_RESOURCE_STATE_GENERIC_READ);
            let readback = buffer(D3D12_HEAP_TYPE_READBACK, D3D12_RESOURCE_STATE_COPY_DEST);
            let mut p = std::ptr::null_mut();
            upload.Map(0, None, Some(&mut p)).unwrap();
            *(p as *mut u32) = 0x7734;
            upload.Unmap(0, None);
            let alloc: ID3D12CommandAllocator = dev.CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT).unwrap();
            let list: ID3D12GraphicsCommandList = dev.CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, &alloc, None).unwrap();
            list.CopyBufferRegion(&readback, 0, &upload, 0, 4);
            list.Close().unwrap();
            SEEN.store(0, Ordering::Relaxed);
            q.Wait(&gate, 1).unwrap();
            q.ExecuteCommandLists(&[Some(list.cast().unwrap())]);
            after(q.as_raw(), vec![Write::Inspect(ReadbackInspection { readback: readback.clone(), dwords: 1,
                callback: inspect, _resources: vec![upload.clone()], _pipelines: Vec::new() })]);
            std::thread::sleep(std::time::Duration::from_millis(20));
            let premature = SEEN.load(Ordering::Acquire);
            // Release the artificial gate before any assertion, even with a broken worker.
            gate.Signal(1).unwrap();
            crate::gpu::texture::wait(&dev, &q).unwrap();
            let start = std::time::Instant::now();
            while SEEN.load(Ordering::Acquire) == 0 && start.elapsed().as_secs() < 5 { std::thread::yield_now(); }
            assert_eq!(premature, 0, "inspection ran before its queue completed");
            assert_eq!(SEEN.load(Ordering::Acquire), 0x7734, "callback must observe the GPU copy");
        }
    }

    /// A pending producer must neither publish after the legacy timeout nor hold up another queue.
    #[test]
    fn pending_producer_retains_writes_and_independent_queue_progresses() {
        unsafe {
            let mut dev: Option<ID3D12Device> = None;
            if D3D12CreateDevice(None, D3D_FEATURE_LEVEL_11_0, &mut dev).is_err() {
                let Ok(factory) = CreateDXGIFactory1::<IDXGIFactory4>() else {
                    crate::gpu::recomp::runner::skip_test("no GPU or WARP device");
                    return;
                };
                let Ok(warp) = factory.EnumWarpAdapter::<IDXGIAdapter>() else {
                    crate::gpu::recomp::runner::skip_test("no GPU or WARP device");
                    return;
                };
                if D3D12CreateDevice(&warp, D3D_FEATURE_LEVEL_11_0, &mut dev).is_err() {
                    crate::gpu::recomp::runner::skip_test("no GPU or WARP device");
                    return;
                }
            }
            let dev = dev.unwrap();
            let blocked: ID3D12Fence = dev.CreateFence(0, D3D12_FENCE_FLAG_NONE).unwrap();
            let ready: ID3D12Fence = dev.CreateFence(1, D3D12_FENCE_FLAG_NONE).unwrap();
            let first = Box::new(AtomicU32::new(0));
            let suffix = Box::new(AtomicU32::new(0));
            let other = Box::new(AtomicU32::new(0));
            let send = |fence: &ID3D12Fence, dst: &AtomicU32, word| {
                // No command lists or GPU waits: real fences are held/signalled by this test.
                worker_for_test(fence.as_raw() as usize).send(Job {
                    fence: fence.clone(), value: 1,
                    writes: vec![Write::Immediate(dst as *const AtomicU32 as usize, vec![word])],
                }).unwrap();
            };
            let start = std::time::Instant::now();
            send(&blocked, &first, 7);
            send(&blocked, &suffix, 9);
            send(&ready, &other, 11);
            while other.load(Ordering::Acquire) == 0 && start.elapsed().as_millis() < 1000 {
                std::thread::sleep(std::time::Duration::from_millis(5));
            }
            let independent_progress = other.load(Ordering::Acquire) == 11;
            std::thread::sleep(std::time::Duration::from_millis(WAIT_MS as u64 + 200).saturating_sub(start.elapsed()));
            let premature = (first.load(Ordering::Acquire), suffix.load(Ordering::Acquire));
            // Always release/drain jobs before assertions so no worker retains a destination
            // that a failing assertion would free.
            blocked.Signal(1).unwrap();
            let drain = std::time::Instant::now();
            while (suffix.load(Ordering::Acquire) != 9 || other.load(Ordering::Acquire) != 11) && drain.elapsed().as_secs() < 5 {
                std::thread::sleep(std::time::Duration::from_millis(5));
            }
            let final_values = (first.load(Ordering::Acquire), suffix.load(Ordering::Acquire), other.load(Ordering::Acquire));
            // On a broken worker that cannot drain, keep destinations alive instead of risking UAF.
            if final_values != (7, 9, 11) { std::mem::forget((first, suffix, other)); }
            assert_eq!(premature, (0, 0), "pending producer or its ordered suffix was published before completion");
            assert!(independent_progress, "another queue was blocked behind an unrelated producer");
            assert_eq!(final_values, (7, 9, 11));
        }
    }

    fn worker_for_test(_queue: usize) -> mpsc::Sender<Job> {
        worker().lock().unwrap().clone()
    }

    /// The value lands after the queue has done what came before it.
    #[test]
    fn writes_land_after_the_queue() {
        unsafe {
            let mut dev: Option<ID3D12Device> = None;
            if D3D12CreateDevice(None, D3D_FEATURE_LEVEL_11_0, &mut dev).is_err() {
                let factory: IDXGIFactory4 = CreateDXGIFactory1().unwrap();
                let warp: IDXGIAdapter = factory.EnumWarpAdapter().unwrap();
                D3D12CreateDevice(&warp, D3D_FEATURE_LEVEL_11_0, &mut dev).expect("WARP D3D12 device");
            }
            let dev = dev.unwrap();
            let q: ID3D12CommandQueue = dev.CreateCommandQueue(&D3D12_COMMAND_QUEUE_DESC { Type: D3D12_COMMAND_LIST_TYPE_DIRECT, ..Default::default() }).unwrap();
            let cell = Box::new([0u32; 2]);
            let va = cell.as_ptr() as usize;
            assert!(writable(va, 8));
            after(q.as_raw(), vec![Write::Immediate(va, vec![7, 9])]);
            let t = std::time::Instant::now();
            while (*(va as *const AtomicU32)).load(Ordering::Acquire) != 7 {
                assert!(t.elapsed().as_secs() < 5, "never written");
                std::thread::yield_now();
            }
            assert_eq!(*cell, [7, 9]);
        }
    }

    /// A ReadbackU64 write copies the 64-bit value from the mapped readback buffer after the queue finishes.
    #[test]
    fn readback_u64_lands_after_the_queue() {
        unsafe {
            let mut dev: Option<ID3D12Device> = None;
            if D3D12CreateDevice(None, D3D_FEATURE_LEVEL_11_0, &mut dev).is_err() {
                let Ok(factory) = CreateDXGIFactory1::<IDXGIFactory4>() else {
                    crate::gpu::recomp::runner::skip_test("no GPU");
                    return;
                };
                let Ok(warp) = factory.EnumWarpAdapter::<IDXGIAdapter>() else {
                    crate::gpu::recomp::runner::skip_test("no GPU");
                    return;
                };
                if D3D12CreateDevice(&warp, D3D_FEATURE_LEVEL_11_0, &mut dev).is_err() {
                    crate::gpu::recomp::runner::skip_test("no GPU");
                    return;
                }
            }
            let dev = dev.unwrap();
            let q: ID3D12CommandQueue = dev.CreateCommandQueue(&D3D12_COMMAND_QUEUE_DESC { Type: D3D12_COMMAND_LIST_TYPE_DIRECT, ..Default::default() }).unwrap();
            let hp = D3D12_HEAP_PROPERTIES { Type: D3D12_HEAP_TYPE_READBACK, ..Default::default() };
            let rd = D3D12_RESOURCE_DESC {
                Dimension: D3D12_RESOURCE_DIMENSION_BUFFER,
                Width: 8,
                Height: 1,
                DepthOrArraySize: 1,
                MipLevels: 1,
                SampleDesc: windows::Win32::Graphics::Dxgi::Common::DXGI_SAMPLE_DESC { Count: 1, Quality: 0 },
                Layout: D3D12_TEXTURE_LAYOUT_ROW_MAJOR,
                ..Default::default()
            };
            let mut rb: Option<ID3D12Resource> = None;
            dev.CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &rd, D3D12_RESOURCE_STATE_COPY_DEST, None, &mut rb).unwrap();
            let rb = rb.unwrap();
            let mut ptr: *mut c_void = std::ptr::null_mut();
            rb.Map(0, None, Some(&mut ptr)).unwrap();
            let expected = 0x1234_5678_9ABC_DEF0u64;
            (*(ptr as *const AtomicU64)).store(expected, Ordering::Release);

            let dst = Box::new(0u64);
            let va = dst.as_ref() as *const u64 as usize;
            assert!(writable(va, 8));
            after(q.as_raw(), vec![Write::ReadbackU64 { va, src: ptr as usize, _buf: rb }]);
            let t = std::time::Instant::now();
            while (*(va as *const AtomicU64)).load(Ordering::Acquire) != expected {
                assert!(t.elapsed().as_secs() < 5, "readback value never written");
                std::thread::yield_now();
            }
            assert_eq!(*dst, expected);
        }
    }
}
