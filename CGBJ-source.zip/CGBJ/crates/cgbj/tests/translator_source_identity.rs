// Build-script cache identity tests run with the workspace regression suite.
#[path = "../build.rs"]
#[allow(dead_code)]
mod build_identity;
