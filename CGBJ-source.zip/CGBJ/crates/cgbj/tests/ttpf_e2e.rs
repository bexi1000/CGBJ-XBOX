// Modified for the CGBJ fork on 2026-11-25: project branding and/or documentation. Original XCL and third-party notices remain applicable.
//! TTPF metadata probes use handmade data, never a game's archive or code.

use std::path::PathBuf;
use std::process::{Command, Output};
use std::sync::atomic::{AtomicU64, Ordering};

static NEXT_FIXTURE: AtomicU64 = AtomicU64::new(0);

struct Fixture(PathBuf);

impl Fixture {
    fn new(bytes: &[u8]) -> Self {
        let nonce = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos();
        let id = NEXT_FIXTURE.fetch_add(1, Ordering::Relaxed);
        let path = std::env::temp_dir().join(format!("cgbj-ttpf-{}-{nonce}-{id}.ttpf", std::process::id()));
        std::fs::write(&path, bytes).unwrap();
        Self(path)
    }

    fn run(&self, args: &[&str]) -> Output {
        Command::new(env!("CARGO_BIN_EXE_cgbj"))
            .arg("ttpf").arg(&self.0).args(args)
            .env_remove("CGBJ_HOST").output().unwrap()
    }
}

impl Drop for Fixture {
    fn drop(&mut self) {
        let _ = std::fs::remove_file(&self.0);
    }
}

fn metadata() -> Vec<u8> {
    let mut bytes = vec![0u8; 0x140];
    bytes[..4].copy_from_slice(b"RDS5");
    bytes[4..8].copy_from_slice(&4u32.to_le_bytes());
    bytes[8..12].copy_from_slice(&0x12345000u32.to_le_bytes());
    bytes[12..16].copy_from_slice(&0x16000002u32.to_le_bytes());
    bytes[16..20].copy_from_slice(&1u32.to_le_bytes());
    bytes[0x108..0x10c].copy_from_slice(&2u32.to_le_bytes());
    bytes
}

#[test]
fn metadata_probe_reports_json_and_text_without_modifying_the_file() {
    let bytes = metadata();
    let fixture = Fixture::new(&bytes);
    let json = fixture.run(&["--json"]);
    assert!(json.status.success(), "{json:?}");
    let out: serde_json::Value = serde_json::from_slice(&json.stdout).unwrap();
    assert_eq!(out["format"], "RDS5");
    assert_eq!(out["logical_file_bytes"], 0x140);
    assert_eq!(out["texture_count_field"], 2);
    assert_eq!(out["unpacked_stream_bytes"], 0x212345000u64);
    assert_eq!(out["metadata_bytes_read"], 40);
    assert_eq!(out["payload_examined"], false);
    assert_eq!(out["archive_complete_verified"], false);
    let text = fixture.run(&[]);
    assert!(text.status.success(), "{text:?}");
    let text = String::from_utf8(text.stdout).unwrap();
    assert!(text.contains("Texture count field: 2"), "{text}");
    assert!(text.contains("not verified"), "{text}");
    assert_eq!(std::fs::read(&fixture.0).unwrap(), bytes);
}

#[test]
fn unavailable_header_is_an_error_without_a_successful_json_report() {
    let fixture = Fixture::new(&[0u8; 24]);
    let out = fixture.run(&["--json"]);
    assert_eq!(out.status.code(), Some(3), "{out:?}");
    assert!(out.stdout.is_empty(), "{out:?}");
    assert!(String::from_utf8_lossy(&out.stderr).contains("RDS5"));
}

#[test]
fn metadata_probe_rejects_unknown_and_duplicate_options() {
    let fixture = Fixture::new(&metadata());
    for args in [&["--unknown"][..], &["--json", "--json"][..]] {
        let out = fixture.run(args);
        assert_eq!(out.status.code(), Some(2), "{out:?}");
        assert!(String::from_utf8_lossy(&out.stderr).contains("options"), "{out:?}");
        assert!(out.stdout.is_empty());
    }
}
