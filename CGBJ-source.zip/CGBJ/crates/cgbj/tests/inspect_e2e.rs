// Modified for the CGBJ fork on 2026-11-25: project branding and/or documentation. Original XCL and third-party notices remain applicable.
//! Inspection must distinguish absent metadata from metadata it could not read.

use std::path::PathBuf;
use std::process::{Command, Output};

struct Fixture {
    dir: PathBuf,
    path: PathBuf,
}

impl Fixture {
    fn new(directory: Option<usize>) -> Self {
        let nonce = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos();
        let dir = std::env::temp_dir().join(format!("cgbj-inspect-{}-{nonce}", std::process::id()));
        std::fs::create_dir(&dir).unwrap();
        let path = dir.join("metadata.exe");
        let mut data = vec![0u8; 512];
        data[..2].copy_from_slice(b"MZ");
        data[60..64].copy_from_slice(&64u32.to_le_bytes());
        data[64..68].copy_from_slice(b"PE\0\0");
        data[68..70].copy_from_slice(&0x8664u16.to_le_bytes());
        data[84..86].copy_from_slice(&240u16.to_le_bytes());
        let opt = 88;
        data[opt..opt + 2].copy_from_slice(&0x20bu16.to_le_bytes());
        data[opt + 24..opt + 32].copy_from_slice(&0x140000000u64.to_le_bytes());
        data[opt + 56..opt + 60].copy_from_slice(&4096u32.to_le_bytes());
        data[opt + 60..opt + 64].copy_from_slice(&512u32.to_le_bytes());
        data[opt + 108..opt + 112].copy_from_slice(&16u32.to_le_bytes());
        if let Some(index) = directory {
            let at = opt + 112 + index * 8;
            data[at..at + 4].copy_from_slice(&0xfffffff0u32.to_le_bytes());
            data[at + 4..at + 8].copy_from_slice(&40u32.to_le_bytes());
        }
        std::fs::write(&path, data).unwrap();
        Self { dir, path }
    }

    fn inspect(&self) -> Output {
        Command::new(env!("CARGO_BIN_EXE_cgbj"))
            .arg("inspect").arg(&self.path).arg("--json")
            .env_remove("CGBJ_HOST")
            .output().unwrap()
    }

    fn importing(symbol: &str, ordinal: Option<u16>, corrupt_provider: bool) -> Self {
        let fixture = Self::new(None);
        let mut data = std::fs::read(&fixture.path).unwrap();
        data.resize(1024, 0);
        data[148..152].copy_from_slice(&1024u32.to_le_bytes());
        let directory = 88 + 112 + cgbj::pe::DIR_IMPORT * 8;
        data[directory..directory + 4].copy_from_slice(&0x200u32.to_le_bytes());
        data[directory + 4..directory + 8].copy_from_slice(&40u32.to_le_bytes());
        data[0x200..0x204].copy_from_slice(&0x240u32.to_le_bytes());
        data[0x20c..0x210].copy_from_slice(&0x280u32.to_le_bytes());
        data[0x210..0x214].copy_from_slice(&0x260u32.to_le_bytes());
        let thunk = ordinal.map(|n| (1u64 << 63) | n as u64).unwrap_or(0x2a0);
        data[0x240..0x248].copy_from_slice(&thunk.to_le_bytes());
        data[0x280..0x28c].copy_from_slice(b"fixture.dll\0");
        data[0x2a2..0x2a2 + symbol.len()].copy_from_slice(symbol.as_bytes());
        std::fs::write(&fixture.path, &data).unwrap();

        if corrupt_provider {
            std::fs::write(fixture.dir.join("fixture.dll"), b"MZ").unwrap();
            return fixture;
        }
        data.fill(0);
        let header = std::fs::read(&fixture.path).unwrap();
        data[..328].copy_from_slice(&header[..328]);
        data[directory..directory + 8].fill(0);
        data[86..88].copy_from_slice(&0x2002u16.to_le_bytes());
        let exports = 88 + 112;
        data[exports..exports + 4].copy_from_slice(&0x300u32.to_le_bytes());
        data[exports + 4..exports + 8].copy_from_slice(&0x80u32.to_le_bytes());
        for (offset, value) in [(12, 0x390u32), (16, 7), (20, 2), (24, 2), (28, 0x360), (32, 0x368), (36, 0x370)] {
            data[0x300 + offset..0x304 + offset].copy_from_slice(&value.to_le_bytes());
        }
        data[0x360..0x364].copy_from_slice(&0x3e0u32.to_le_bytes());
        // Function slot 1 is a null export; neither its name nor ordinal is provided.
        data[0x368..0x36c].copy_from_slice(&0x3a0u32.to_le_bytes());
        data[0x36c..0x370].copy_from_slice(&0x3b0u32.to_le_bytes());
        data[0x372..0x374].copy_from_slice(&1u16.to_le_bytes());
        data[0x390..0x39c].copy_from_slice(b"fixture.dll\0");
        data[0x3a0..0x3aa].copy_from_slice(b"Available\0");
        data[0x3b0..0x3b9].copy_from_slice(b"NullSlot\0");
        std::fs::write(fixture.dir.join("fixture.dll"), data).unwrap();
        fixture
    }
}

impl Drop for Fixture {
    fn drop(&mut self) {
        let _ = std::fs::remove_file(self.dir.join("fixture.dll"));
        let _ = std::fs::remove_file(&self.path);
        let _ = std::fs::remove_dir(&self.dir);
    }
}

fn rejects_directory(index: usize, diagnostic: &str) {
    let fixture = Fixture::new(Some(index));
    let output = fixture.inspect();
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_eq!(output.status.code(), Some(3), "malformed {diagnostic} reported success: {output:?}");
    assert!(stderr.contains(diagnostic), "missing {diagnostic} diagnostic: {stderr}");
    assert!(output.stdout.is_empty(), "must not emit a successful JSON report: {output:?}");
}

#[test]
fn malformed_imports_are_not_reported_as_no_imports() {
    rejects_directory(cgbj::pe::DIR_IMPORT, "import table");
    let fixture = Fixture::new(Some(cgbj::pe::DIR_IMPORT));
    assert_eq!(cgbj::inspect::console_imports(&fixture.path), None);
}

#[test]
fn malformed_delay_imports_are_not_reported_as_no_imports() {
    rejects_directory(cgbj::pe::DIR_DELAY_IMPORT, "delay import table");
    let fixture = Fixture::new(Some(cgbj::pe::DIR_DELAY_IMPORT));
    assert_eq!(cgbj::inspect::console_imports(&fixture.path), None);
}

#[test]
fn malformed_tls_is_not_reported_as_absent() {
    rejects_directory(cgbj::pe::DIR_TLS, "TLS directory");
}

#[test]
fn absent_metadata_remains_a_valid_inspection() {
    let fixture = Fixture::new(None);
    let output = fixture.inspect();
    assert!(output.status.success(), "{output:?}");
    let report: serde_json::Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(report["imports"], serde_json::json!([]));
    assert!(report["tls_template_bytes"].is_null());
    assert_eq!(cgbj::inspect::console_imports(&fixture.path), Some(Vec::new()));
}

fn provider_status(symbol: &str, ordinal: Option<u16>, corrupt: bool) -> String {
    let fixture = Fixture::importing(symbol, ordinal, corrupt);
    let output = fixture.inspect();
    assert!(output.status.success(), "{output:?}");
    let report: serde_json::Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(report["imports"].as_array().unwrap().len(), 1);
    report["imports"][0]["status"].as_str().unwrap().to_string()
}

#[test]
fn game_dll_must_export_the_requested_name() {
    assert_eq!(provider_status("Missing", None, false), "STUB");
}

#[test]
fn corrupt_game_dll_is_not_a_provider() {
    assert_eq!(provider_status("Available", None, true), "STUB");
}

#[test]
fn a_null_named_export_is_not_a_provider() {
    assert_eq!(provider_status("NullSlot", None, false), "STUB");
}

#[test]
fn a_null_ordinal_export_is_not_a_provider() {
    assert_eq!(provider_status("", Some(8), false), "STUB");
}

#[test]
fn present_named_exports_remain_game_dll_imports() {
    assert_eq!(provider_status("Available", None, false), "game DLL (fixture.dll)");
}

#[test]
fn present_ordinal_exports_remain_game_dll_imports() {
    assert_eq!(provider_status("", Some(7), false), "game DLL (fixture.dll)");
}
