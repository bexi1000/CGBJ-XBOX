// Modified for the CGBJ fork on 2026-11-25: project branding and/or documentation. Original XCL and third-party notices remain applicable.
//! Isolated allocation/reuse race regression, adapted from XCL's GPL-2.0-only
//! commit ebbf3779791aff8988c4b742ba629c561928333c. Initialize the GPU explicitly
//! so this test cannot silently pass because another test did not initialize it.

use std::sync::{Arc, Barrier};

use cgbj::hle::d3d12x::{real, sparse};

#[test]
fn freed_sparse_blocks_are_decommitted_before_reuse() {
    if real::init().is_err() {
        cgbj::gpu::recomp::runner::skip_test("no GPU");
        return;
    }
    if cgbj::gpu::uma::get().is_none_or(|u| !u.has_sparse()) {
        cgbj::gpu::recomp::runner::skip_test("no sparse GPU windows");
        return;
    }
    let start = Arc::new(Barrier::new(4));
    let threads: Vec<_> = (0..4u64)
        .map(|worker| {
            let start = start.clone();
            std::thread::spawn(move || unsafe {
                start.wait();
                for i in 0..2000u64 {
                    let (p, n) = sparse::alloc(0x1_0000, 0x1_0000).expect("a sparse block");
                    let value = (worker << 32) | i;
                    std::ptr::write_volatile(p as *mut u64, value);
                    std::ptr::write_volatile((p + n - 8) as *mut u64, value);
                    assert_eq!(std::ptr::read_volatile(p as *const u64), value);
                    assert_eq!(std::ptr::read_volatile((p + n - 8) as *const u64), value);
                    assert!(sparse::free(p));
                }
            })
        })
        .collect();
    for thread in threads {
        thread.join().unwrap();
    }
}
