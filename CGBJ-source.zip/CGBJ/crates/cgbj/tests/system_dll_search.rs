// Modified for the CGBJ fork on 2026-11-25: project branding and/or documentation. Original XCL and third-party notices remain applicable.
//! Windows fallback providers must not come from a title's directory or PATH.

use std::path::PathBuf;
use std::process::Command;

fn check_external_provider(test_name: &str, absolute: bool) {
    const PROBE: &str = "CGBJ_TEST_SYSTEM_DLL_PROBE";
    if let Some(path) = std::env::var_os(PROBE) {
        let path = PathBuf::from(path);
        let name = if absolute { path.as_os_str() } else { path.file_name().unwrap() };
        assert!(cgbj::resolver::system_module(&name.to_string_lossy()).is_none(),
            "system fallback loaded a provider outside System32: {}", path.display());
        return;
    }

    let nonce = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos();
    let dir = std::env::temp_dir().join(format!("cgbj-system-dll-{}-{nonce}", std::process::id()));
    std::fs::create_dir(&dir).unwrap();
    let path = dir.join(format!("cgbj_provider_{nonce}.dll"));
    // A renamed, genuine Windows library demonstrates the search behavior without a payload.
    let system_root = std::env::var_os("SystemRoot").expect("Windows directory");
    std::fs::copy(PathBuf::from(system_root).join("System32").join("version.dll"), &path).unwrap();
    let mut search = vec![dir.clone()];
    if let Some(old) = std::env::var_os("PATH") {
        search.extend(std::env::split_paths(&old));
    }
    let output = Command::new(std::env::current_exe().unwrap())
        .arg("--exact").arg(test_name).arg("--nocapture")
        .current_dir(&dir)
        .env(PROBE, &path)
        .env("PATH", std::env::join_paths(search).unwrap())
        .env_remove("CGBJ_HOST")
        .output();
    // The child has exited before the copied Windows DLL is removed.
    let _ = std::fs::remove_file(&path);
    let _ = std::fs::remove_dir(&dir);
    let output = output.unwrap();
    assert!(output.status.success(), "{output:?}");
}

#[test]
fn system_module_ignores_current_directory_and_path() {
    check_external_provider("system_module_ignores_current_directory_and_path", false);
}

#[test]
fn system_module_ignores_external_absolute_paths() {
    check_external_provider("system_module_ignores_external_absolute_paths", true);
}

#[test]
fn genuine_system_functions_and_api_sets_still_resolve() {
    use cgbj::pe::ImportName;
    let named = |name: &str| ImportName::Name { hint: 0, name: name.into() };
    assert!(cgbj::resolver::system_proc("kernel32.dll", &named("GetProcAddress")).is_some());
    assert!(cgbj::resolver::system_proc("api-ms-win-core-synch-l1-2-0.dll", &named("Sleep")).is_some());
}
