// Modified for the CGBJ fork on 2026-11-25: project branding and/or documentation. Original XCL and third-party notices remain applicable.
//! Prefer lower bottom-up addresses for console code with 40-bit address fields (#585, #631).

use std::path::{Path, PathBuf};

// Conservative translation identity: all GPU sources except standalone test/runner files.
// Runtime/HLE diagnostics and link metadata do not discard translations. Adapted from XCL's
// source-keyed cache design at c160d86 (GPL-2.0-only); this local HLSL path has no direct backend.
fn gpu_sources(dir: &Path, out: &mut Vec<PathBuf>) {
    for entry in std::fs::read_dir(dir).expect("GPU source directory") {
        let path = entry.expect("GPU source entry").path();
        if path.is_dir() { gpu_sources(&path, out); }
        else if path.extension().is_some_and(|e| e == "rs")
            && !matches!(path.file_name().and_then(|s| s.to_str()), Some("tests.rs" | "runner.rs")) { out.push(path); }
    }
}

fn source_identity(root: &Path, target: &str) -> (u64, Vec<PathBuf>) {
    let mut paths = Vec::new();
    gpu_sources(&root.join("src/gpu"), &mut paths);
    paths.sort();
    let mut h = 0xcbf2_9ce4_8422_2325u64;
    let mut add = |bytes: &[u8]| { for b in bytes.iter().copied().chain([0]) { h ^= b as u64; h = h.wrapping_mul(0x100_0000_01b3); } };
    add(b"cgbj-local-hlsl-cache-v2");
    add(target.as_bytes());
    for path in &paths {
        add(path.strip_prefix(root).unwrap().to_string_lossy().replace('\\', "/").as_bytes());
        add(&std::fs::read(path).expect("GPU translator source"));
    }
    (h | 1, paths)
}

fn main() {
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:rerun-if-changed=src/gpu");
    let root = PathBuf::from(std::env::var_os("CARGO_MANIFEST_DIR").expect("manifest directory"));
    let (identity, paths) = source_identity(&root, &std::env::var("TARGET").expect("build target"));
    for path in paths { println!("cargo:rerun-if-changed={}", path.display()); }
    println!("cargo:rustc-env=CGBJ_TRANSLATOR_SOURCE_ID={identity:016x}");
    match std::env::var("CARGO_CFG_TARGET_ENV").as_deref() {
        Ok("msvc") => println!("cargo:rustc-link-arg-bin=cgbj=/HIGHENTROPYVA:NO"),
        Ok("gnu") => println!("cargo:rustc-link-arg-bin=cgbj=-Wl,--disable-high-entropy-va"),
        _ => {}
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn runtime_diagnostics_do_not_discard_translations_but_gpu_sources_and_target_do() {
        let root = std::env::temp_dir().join(format!("cgbj-source-id-{}", std::process::id()));
        std::fs::create_dir_all(root.join("src/gpu/recomp")).unwrap();
        std::fs::create_dir_all(root.join("src/hle")).unwrap();
        std::fs::write(root.join("src/gpu/recomp/emit.rs"), b"translator a").unwrap();
        let a = source_identity(&root, "windows").0;
        std::fs::write(root.join("src/hle/trace.rs"), b"new runtime logging").unwrap();
        std::fs::write(root.join("src/gpu/recomp/tests.rs"), b"new tests").unwrap();
        assert_eq!(source_identity(&root, "windows").0, a);
        assert_ne!(source_identity(&root, "other-target").0, a);
        std::fs::write(root.join("src/gpu/recomp/emit.rs"), b"translator b").unwrap();
        assert_ne!(source_identity(&root, "windows").0, a);
        std::fs::remove_dir_all(root).unwrap();
    }
}
